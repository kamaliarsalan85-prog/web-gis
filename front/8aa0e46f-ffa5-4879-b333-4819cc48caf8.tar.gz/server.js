// server.js
import express from 'express';
import fs from 'fs/promises';
import path from 'path';
import cors from 'cors';
import { fileURLToPath } from 'url';
import multer from 'multer';
import mongoose from 'mongoose';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import dotenv from 'dotenv';
import { Server } from 'socket.io';
import http from 'http';
import https from 'https';
import bodyParser from 'body-parser';
import axios from 'axios';
import compression from 'compression';
import crypto from 'crypto';
import brotli from 'brotli';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const server = http.createServer(app);
const io = new Server(server, {
  cors: {
    origin: (origin, cb) => { if (!origin) return cb(null, true); const ALLOWED_ORIGINS = (process.env.CORS_ORIGIN || '').split(',').map(s => s.trim()).filter(Boolean); return ALLOWED_ORIGINS.length === 0 || ALLOWED_ORIGINS.includes(origin) ? cb(null, true) : cb(new Error('Not allowed by CORS')); },
    methods: ['GET', 'POST', 'PUT', 'DELETE'],
    allowedHeaders: ['Authorization', 'Content-Type'],
    credentials: true,
  },
});

app.use(
  cors({
    origin: (origin, cb) => { if (!origin) return cb(null, true); const ALLOWED_ORIGINS = (process.env.CORS_ORIGIN || '').split(',').map(s => s.trim()).filter(Boolean); return ALLOWED_ORIGINS.length === 0 || ALLOWED_ORIGINS.includes(origin) ? cb(null, true) : cb(new Error('Not allowed by CORS')); },
    methods: ['GET', 'POST', 'PUT', 'DELETE'],
    allowedHeaders: ['Authorization', 'Content-Type'],
    credentials: true,
  })
);
// compress responses (gzip/brotli if node supports it + client accepts)
app.set('trust proxy', 1);
app.use(compression());
app.use(bodyParser.json({ limit: '100mb' }));
app.use(bodyParser.urlencoded({ limit: '100mb', extended: true }));

// ---------- Directories ----------
const DATA_DIR = path.join(__dirname, 'data'); // local layers directory
await fs.mkdir(DATA_DIR, { recursive: true }).catch((err) =>
  console.error('Failed to create data directory:', err)
);

// CACHE_DIR: separate directory for caches (main-parcels cache lives here)
const CACHE_DIR = path.join(__dirname, 'cache');
await fs.mkdir(CACHE_DIR, { recursive: true }).catch((err) =>
  console.error('Failed to create cache directory:', err)
);

// PARCELS_CACHE_FILE now points inside CACHE_DIR (option B)
const PARCELS_CACHE_FILE = path.join(CACHE_DIR, 'main-parcels-cache.json');
const MAHALLES_CACHE_FILE = path.join(CACHE_DIR, 'main-mahalles-cache.json');
// NEW: add mabar cache file
const MABAR_CACHE_FILE = path.join(CACHE_DIR, 'main-mabar-cache.json');

const upload = multer({ storage: multer.memoryStorage() });

const MONGO_URI = process.env.MONGO_URI;
if (!MONGO_URI) {
  console.error('MONGO_URI is not set in .env');
  process.exit(1);
}

mongoose
  .connect(MONGO_URI, {
    useNewUrlParser: true,
    useUnifiedTopology: true,
  })
  .then(() => console.log('Connected to MongoDB'))
  .catch((err) => {
    console.error('MongoDB connection error:', err);
    process.exit(1);
  });

// ---------- Schemas ----------
const userSchema = new mongoose.Schema({
  username: { type: String, unique: true, required: true },
  password: { type: String, required: true },
  role: { type: String, enum: ['admin', 'user', 'editor'], default: 'user' },
  tools: [
    {
      type: String,
      enum: [
        'stats',
        'edit',
        'export',
        'spatial',
        'visual',
        'network',
        'join',
        'modeling',
        'draw',
        'filter',
        'search',
      ],
    },
  ],
  layers: [{ type: String }],
});

const layerSchema = new mongoose.Schema({
  name: { type: String, unique: true, required: true },
  data: { type: Object, required: true },
  storage: { type: String, enum: ['db'], default: 'db' },
  createdAt: { type: Date, default: Date.now },
  updatedAt: { type: Date, default: Date.now },
});

const User = mongoose.model('User', userSchema);
const Layer = mongoose.model('Layer', layerSchema);

// ---------- Auth middlewares ----------
const authMiddleware = (req, res, next) => {
  const token = req.headers['authorization']?.split(' ')?.[1];
  if (!token) {
    return res.status(401).json({
      status: 'error',
      error: 'Authentication required. Please provide a valid token.',
    });
  }

  try {
    const secret = process.env.JWT_SECRET;
    if (!secret) throw new Error('JWT_SECRET not set');
    const decoded = jwt.verify(token, secret);
    req.user = decoded;
    next();
  } catch (error) {
    res.status(401).json({
      status: 'error',
      error: 'Invalid or expired token',
      details: error.message,
    });
  }
};

const adminMiddleware = (req, res, next) => {
  if (req.user?.role !== 'admin') {
    return res.status(403).json({
      status: 'error',
      error: 'Access denied. Admin privileges required.',
    });
  }
  next();
};

// ---------- external axios with keep-alive ----------
const externalAxios = axios.create({
  baseURL: process.env.MAHALLE_API || process.env.EXTERNAL_API_BASE || 'https://hominex-backend.ir',
  timeout: 15000,
  httpsAgent: new https.Agent({ keepAlive: true, maxSockets: 50 }),
});

// convenience mahalle endpoints root
const MAHALLE_PREFIX = '/api/mahalle';

// simple concurrency limiter (no external dependency)
const pLimit = (limit) => {
  let active = 0;
  const queue = [];

  const next = () => {
    if (active >= limit || queue.length === 0) return;
    active++;
    const { fn, resolve, reject } = queue.shift();
    fn()
      .then((v) => resolve(v))
      .catch((e) => reject(e))
      .finally(() => {
        active--;
        next();
      });
  };

  return (fn) =>
    new Promise((resolve, reject) => {
      queue.push({ fn, resolve, reject });
      next();
    });
};

// ---------- sendToFakeSync ----------
const sendToFakeSync = async (action, layerName, data) => {
  try {
    await externalAxios.post('/api/fake-sync', { action, layerName, data });
    console.log(`Changes sent to fake-sync: ${action} on ${layerName}`);
  } catch (error) {
    console.error('Failed to send to fake-sync:', error.message);
  }
};

// ---------- parcels-geojson, mahalles & mabar cache & fetch (conditional requests) ----------
const DEFAULT_CACHE_TTL_MS = process.env.CACHE_TTL_MS ? Number(process.env.CACHE_TTL_MS) : 30 * 1000;
const CACHE_TTL_MS = DEFAULT_CACHE_TTL_MS;

// optional per-layer TTL map (e.g., process.env.PARCELS_TTL_MS)
const LAYER_TTLS = {
  'main-parcels': process.env.PARCELS_TTL_MS ? Number(process.env.PARCELS_TTL_MS) : CACHE_TTL_MS,
  'main-mahalles': process.env.MAHALLES_TTL_MS ? Number(process.env.MAHALLES_TTL_MS) : CACHE_TTL_MS,
  'main-mabar': process.env.MABAR_TTL_MS ? Number(process.env.MABAR_TTL_MS) : CACHE_TTL_MS,
};

// parcelsCache structure - keep same fields as before
let parcelsCache = {
  data: null,
  etag: null,
  lastModified: null,
  updatedAt: 0,
  fetchPromise: null,
};

// mahalles cache
let mahallesCache = {
  data: null,
  etag: null,
  lastModified: null,
  updatedAt: 0,
  fetchPromise: null,
};

// NEW: mabar cache
let mabarCache = {
  data: null,
  etag: null,
  lastModified: null,
  updatedAt: 0,
  fetchPromise: null,
};

// generic helper to write cache file with metadata
const writeCacheFile = async (filePath, { data, etag, lastModified, updatedAt }) => {
  const payload = {
    meta: {
      etag: etag ?? null,
      lastModified: lastModified ?? null,
      updatedAt: updatedAt ?? Date.now(),
    },
    data,
  };
  await fs.writeFile(filePath, JSON.stringify(payload, null, 2), 'utf8');
};

const writeParcelsToFile = async (data, meta = {}) =>
  writeCacheFile(PARCELS_CACHE_FILE, { data, ...meta });

const writeMahallesToFile = async (data, meta = {}) =>
  writeCacheFile(MAHALLES_CACHE_FILE, { data, ...meta });

const writeMabarToFile = async (data, meta = {}) =>
  writeCacheFile(MABAR_CACHE_FILE, { data, ...meta });

const fetchParcelsFromExternal = async () => {
  // if someone already fetching, reuse the promise (coalescing)
  if (parcelsCache.fetchPromise) {
    try {
      await parcelsCache.fetchPromise;
      return { fromCache: true, data: parcelsCache.data };
    } catch (e) {
      // fallthrough to try again below
    }
  }

  // create a new fetch promise and store it
  let resolver;
  parcelsCache.fetchPromise = new Promise((resolve, reject) => { resolver = { resolve, reject }; });

  const start = Date.now();
  try {
    const headers = {};
    if (parcelsCache.etag) headers['If-None-Match'] = parcelsCache.etag;
    if (parcelsCache.lastModified) headers['If-Modified-Since'] = parcelsCache.lastModified;

    const resp = await externalAxios.get('/api/parcels-geojson/', { headers, validateStatus: null });

    if (resp.status === 200 && resp.data) {
      parcelsCache.data = resp.data;
      parcelsCache.etag = resp.headers?.etag ?? 'W/"' + hashForETag(resp.data) + '"';
      parcelsCache.lastModified = resp.headers?.['last-modified'] ?? parcelsCache.lastModified;
      parcelsCache.updatedAt = Date.now();

      // persist both data and metadata
      writeParcelsToFile(resp.data, {
        etag: parcelsCache.etag,
        lastModified: parcelsCache.lastModified,
        updatedAt: parcelsCache.updatedAt,
      }).catch(() => {});

      console.log(`Fetched parcels (200) in ${Date.now() - start}ms; bytes=${JSON.stringify(resp.data).length}`);
      resolver.resolve();
      parcelsCache.fetchPromise = null;
      return { fromCache: false, data: resp.data };
    }

    if (resp.status === 304) {
      parcelsCache.updatedAt = Date.now();
      console.log(`Parcels not modified (304) — using cached data.`);
      resolver.resolve();
      parcelsCache.fetchPromise = null;
      return { fromCache: true, data: parcelsCache.data };
    }

    if (parcelsCache.data) {
      console.warn(`Upstream returned ${resp.status}; returning stale cache`);
      resolver.resolve();
      parcelsCache.fetchPromise = null;
      return { fromCache: true, data: parcelsCache.data };
    }

    throw new Error(`Upstream returned status ${resp.status}`);
  } catch (err) {
    // special-case 304 in axios error path
    if (err?.response?.status === 304) {
      parcelsCache.updatedAt = Date.now();
      resolver.resolve();
      parcelsCache.fetchPromise = null;
      return { fromCache: true, data: parcelsCache.data };
    }
    console.error('Failed to fetch parcels from external:', err.message);
    resolver.reject(err);
    parcelsCache.fetchPromise = null;
    throw err;
  }
};

const fetchMahallesFromExternal = async () => {
  // if someone already fetching, reuse the promise (coalescing)
  if (mahallesCache.fetchPromise) {
    try {
      await mahallesCache.fetchPromise;
      return { fromCache: true, data: mahallesCache.data };
    } catch (e) {
      // fallthrough to try again below
    }
  }

  // create a new fetch promise and store it
  let resolver;
  mahallesCache.fetchPromise = new Promise((resolve, reject) => { resolver = { resolve, reject }; });

  const start = Date.now();
  try {
    const headers = {};
    if (mahallesCache.etag) headers['If-None-Match'] = mahallesCache.etag;
    if (mahallesCache.lastModified) headers['If-Modified-Since'] = mahallesCache.lastModified;

    const resp = await externalAxios.get('/api/mahalles', { headers, validateStatus: null });

    if (resp.status === 200 && resp.data) {
      // Convert DRF paginated response to GeoJSON FeatureCollection
      let geojsonData = { type: 'FeatureCollection', features: [] };
      if (resp.data.results && Array.isArray(resp.data.results)) {
        geojsonData.features = resp.data.results.map((item) => ({
          type: 'Feature',
          id: item.id,
          geometry: item.geometry,
          properties: {
            ...(item.properties || {}),
            created_at: item.created_at,
            updated_at: item.updated_at,
            is_active: item.is_active,
          },
        }));
      } else if (resp.data.type === 'FeatureCollection') {
        geojsonData = resp.data;
      }

      mahallesCache.data = geojsonData;
      mahallesCache.etag = resp.headers?.etag ?? 'W/"' + hashForETag(geojsonData) + '"';
      mahallesCache.lastModified = resp.headers?.['last-modified'] ?? mahallesCache.lastModified;
      mahallesCache.updatedAt = Date.now();

      // persist both data and metadata
      writeMahallesToFile(geojsonData, {
        etag: mahallesCache.etag,
        lastModified: mahallesCache.lastModified,
        updatedAt: mahallesCache.updatedAt,
      }).catch(() => {});

      console.log(`Fetched mahalles (200) in ${Date.now() - start}ms; bytes=${JSON.stringify(geojsonData).length}`);
      resolver.resolve();
      mahallesCache.fetchPromise = null;
      return { fromCache: false, data: geojsonData };
    }

    if (resp.status === 304) {
      mahallesCache.updatedAt = Date.now();
      console.log(`Mahalles not modified (304) — using cached data.`);
      resolver.resolve();
      mahallesCache.fetchPromise = null;
      return { fromCache: true, data: mahallesCache.data };
    }

    if (mahallesCache.data) {
      console.warn(`Upstream returned ${resp.status}; returning stale cache`);
      resolver.resolve();
      mahallesCache.fetchPromise = null;
      return { fromCache: true, data: mahallesCache.data };
    }

    throw new Error(`Upstream returned status ${resp.status}`);
  } catch (err) {
    // special-case 304 in axios error path
    if (err?.response?.status === 304) {
      mahallesCache.updatedAt = Date.now();
      resolver.resolve();
      mahallesCache.fetchPromise = null;
      return { fromCache: true, data: mahallesCache.data };
    }
    console.error('Failed to fetch mahalles from external:', err.message);
    resolver.reject(err);
    mahallesCache.fetchPromise = null;
    throw err;
  }
};

// NEW: fetch data from /mabar-simple/ as a read-only external layer (main-mabar)
const fetchMabarFromExternal = async () => {
  // if someone already fetching, reuse the promise (coalescing)
  if (mabarCache.fetchPromise) {
    try {
      await mabarCache.fetchPromise;
      return { fromCache: true, data: mabarCache.data };
    } catch (e) {
      // fallthrough to try again below
    }
  }

  // create a new fetch promise and store it
  let resolver;
  mabarCache.fetchPromise = new Promise((resolve, reject) => { resolver = { resolve, reject }; });

  const start = Date.now();
  try {
    const headers = {};
    if (mabarCache.etag) headers['If-None-Match'] = mabarCache.etag;
    if (mabarCache.lastModified) headers['If-Modified-Since'] = mabarCache.lastModified;

    // try root of mabar-simple; the exact structure upstream may vary, so handle multiple shapes
    const resp = await externalAxios.get('/mabar-simple/', { headers, validateStatus: null });

    if (resp.status === 200 && resp.data) {
      // Normalize to GeoJSON FeatureCollection if possible
      let geojsonData = { type: 'FeatureCollection', features: [] };

      // Common cases:
      // - resp.data.results (DRF) -> map to features
      // - resp.data.features (already GeoJSON)
      // - resp.data itself is a Feature or FeatureCollection
      if (resp.data.results && Array.isArray(resp.data.results)) {
        geojsonData.features = resp.data.results.map((item) => {
          // item may already be a geo feature or contain geometry/properties fields
          let geometry = item.geometry ?? item.geom ?? item.geo ?? null;
          if (item.geometry_json) {
            try {
              geometry = JSON.parse(item.geometry_json);
            } catch (parseErr) {
              console.error('Failed to parse geometry_json for item:', parseErr.message);
            }
          }
          if (item.type === 'Feature') return { ...item, geometry };
          return {
            type: 'Feature',
            id: item.id ?? item.properties?.OBJECTID ?? item.pk ?? undefined,
            geometry,
            properties: { ...(item.properties || {}), ...(item.extra || {}) },
          };
        });
      } else if (resp.data.type === 'FeatureCollection' && Array.isArray(resp.data.features)) {
        geojsonData = { ...resp.data };
        geojsonData.features = geojsonData.features.map((feature) => {
          let geometry = feature.geometry;
          if (feature.properties?.geometry_json) {
            try {
              geometry = JSON.parse(feature.properties.geometry_json);
            } catch (parseErr) {
              console.error('Failed to parse geometry_json in properties:', parseErr.message);
            }
          } else if (feature.geometry_json) {
            try {
              geometry = JSON.parse(feature.geometry_json);
            } catch (parseErr) {
              console.error('Failed to parse geometry_json in feature:', parseErr.message);
            }
          }
          return { ...feature, geometry };
        });
      } else if (Array.isArray(resp.data)) {
        // top-level array -> assume list of features or items convertible to features
        geojsonData.features = resp.data.map((item) => {
          let geometry = item.geometry ?? item.geom ?? null;
          if (item.geometry_json) {
            try {
              geometry = JSON.parse(item.geometry_json);
            } catch (parseErr) {
              console.error('Failed to parse geometry_json for item:', parseErr.message);
            }
          }
          if (item.type === 'Feature') return { ...item, geometry };
          return {
            type: 'Feature',
            id: item.id ?? item.properties?.OBJECTID ?? undefined,
            geometry,
            properties: { ...(item.properties || {}), ...(item.extra || {}) },
          };
        });
      } else if (resp.data.type === 'Feature') {
        let geometry = resp.data.geometry;
        if (resp.data.geometry_json) {
          try {
            geometry = JSON.parse(resp.data.geometry_json);
          } catch (parseErr) {
            console.error('Failed to parse geometry_json for single feature:', parseErr.message);
          }
        }
        geojsonData.features = [{ ...resp.data, geometry }];
      } else {
        // fallback: try to see if resp.data has items under a key like items, data, features
        const candidate =
          resp.data.items || resp.data.data || resp.data.features || null;
        if (Array.isArray(candidate)) {
          geojsonData.features = candidate.map((item) => {
            let geometry = item.geometry ?? item.geom ?? null;
            if (item.geometry_json) {
              try {
                geometry = JSON.parse(item.geometry_json);
              } catch (parseErr) {
                console.error('Failed to parse geometry_json for candidate item:', parseErr.message);
              }
            }
            if (item.type === 'Feature') return { ...item, geometry };
            return {
              type: 'Feature',
              id: item.id ?? item.properties?.OBJECTID ?? undefined,
              geometry,
              properties: { ...(item.properties || {}), ...(item.extra || {}) },
            };
          });
        } else {
          // could not convert cleanly — store raw response as a single feature property
          let geometry = null;
          if (resp.data.geometry_json) {
            try {
              geometry = JSON.parse(resp.data.geometry_json);
            } catch (parseErr) {
              console.error('Failed to parse geometry_json for raw:', parseErr.message);
            }
          }
          geojsonData.features = [
            {
              type: 'Feature',
              id: 'mabar_raw_1',
              geometry,
              properties: { raw: resp.data },
            },
          ];
        }
      }

      mabarCache.data = geojsonData;
      mabarCache.etag = resp.headers?.etag ?? 'W/"' + hashForETag(geojsonData) + '"';
      mabarCache.lastModified = resp.headers?.['last-modified'] ?? mabarCache.lastModified;
      mabarCache.updatedAt = Date.now();

      // persist both data and metadata
      writeMabarToFile(geojsonData, {
        etag: mabarCache.etag,
        lastModified: mabarCache.lastModified,
        updatedAt: mabarCache.updatedAt,
      }).catch(() => {});

      console.log(`Fetched mabar (200) in ${Date.now() - start}ms; bytes=${JSON.stringify(geojsonData).length}`);
      resolver.resolve();
      mabarCache.fetchPromise = null;
      return { fromCache: false, data: geojsonData };
    }

    if (resp.status === 304) {
      mabarCache.updatedAt = Date.now();
      console.log(`Mabar not modified (304) — using cached data.`);
      resolver.resolve();
      mabarCache.fetchPromise = null;
      return { fromCache: true, data: mabarCache.data };
    }

    if (mabarCache.data) {
      console.warn(`Upstream returned ${resp.status}; returning stale mabar cache`);
      resolver.resolve();
      mabarCache.fetchPromise = null;
      return { fromCache: true, data: mabarCache.data };
    }

    throw new Error(`Upstream returned status ${resp.status}`);
  } catch (err) {
    // special-case 304 in axios error path
    if (err?.response?.status === 304) {
      mabarCache.updatedAt = Date.now();
      resolver.resolve();
      mabarCache.fetchPromise = null;
      return { fromCache: true, data: mabarCache.data };
    }
    console.error('Failed to fetch mabar from external:', err.message);
    resolver.reject(err);
    mabarCache.fetchPromise = null;
    throw err;
  }
};

// load caches from disk at startup (best-effort) — now reads PARCELS_CACHE_FILE & MAHALLES_CACHE_FILE & MABAR_CACHE_FILE inside CACHE_DIR
(async () => {
  const load = async (filePath, cacheObj, name) => {
    try {
      const content = await fs.readFile(filePath, 'utf8');
      const parsed = JSON.parse(content);
      cacheObj.data = parsed.data ?? null;
      cacheObj.etag = parsed.meta?.etag ?? cacheObj.etag;
      cacheObj.lastModified = parsed.meta?.lastModified ?? cacheObj.lastModified;
      cacheObj.updatedAt = parsed.meta?.updatedAt ?? Date.now();
      console.log(`Loaded ${name} cache from disk (${filePath})`);
    } catch (e) {
      console.log(`No ${name} cache file found on startup (this is normal on first run).`);
    }
  };

  await load(PARCELS_CACHE_FILE, parcelsCache, 'parcels');
  await load(MAHALLES_CACHE_FILE, mahallesCache, 'mahalles');
  await load(MABAR_CACHE_FILE, mabarCache, 'mabar');
})();

// Helper: normalize layer object returned to client
const makeLayerResponse = (rawLayer, storage = 'db') => {
  if (!rawLayer) return null;
  if (storage === 'db') {
    // mongoose doc
    const data = rawLayer.data ?? {};
    const updatedAt = rawLayer.updatedAt ? new Date(rawLayer.updatedAt).toISOString() : new Date().toISOString();
    const version = rawLayer.updatedAt ? rawLayer.updatedAt.getTime() : Date.now();
    return {
      name: rawLayer.name,
      data,
      storage: 'db',
      updatedAt,
      version,
      color: rawLayer.color,
    };
  } else {
    // plain object for local file
    const updatedAt = rawLayer.updatedAt ?? new Date().toISOString();
    const version = rawLayer.version ?? Date.now();
    return {
      name: rawLayer.name,
      data: rawLayer.data,
      storage: 'local',
      updatedAt,
      version,
      color: rawLayer.color,
    };
  }
};

// sanitize layer/file names safely (avoid unicode-regex pitfalls)
const sanitizeLayerName = (name) => {
  if (!name || typeof name !== 'string') return `layer_${Date.now()}`;
  // basename without extension
  const base = path.basename(name, path.extname(name));
  // keep ASCII letters, digits, underscore and dash; replace others with underscore
  return base.replace(/[^a-zA-Z0-9_-]/g, '_').replace(/_+/g, '_').replace(/^_+|_+$/g, '') || `layer_${Date.now()}`;
};

// ---------- Socket ----------
io.on('connection', (socket) => {
  console.log('User connected to socket');
  socket.on('disconnect', () => console.log('User disconnected'));
});

// helper: send cache headers to client and handle conditional request
const respondWithCache = (req, res, cacheObj, name) => {
  if (!cacheObj || !cacheObj.data) return false;

  if (cacheObj.etag) res.setHeader('ETag', cacheObj.etag);
  if (cacheObj.lastModified) res.setHeader('Last-Modified', cacheObj.lastModified);
  // let client cache (public) for short time, but still validate with ETag
  res.setHeader('Cache-Control', `public, max-age=${Math.floor(CACHE_TTL_MS / 1000)}, must-revalidate`);

  const inm = req.headers['if-none-match'];
  const ims = req.headers['if-modified-since'];
  if (inm && cacheObj.etag && inm === cacheObj.etag) {
    res.status(304).end();
    return true;
  }
  if (ims && cacheObj.lastModified && new Date(cacheObj.lastModified).getTime() <= Date.parse(ims)) {
    res.status(304).end();
    return true;
  }

  return false;
};


// --- Debug request logger (place after bodyParser middlewares, before your routes) ---
app.use((req, res, next) => {
  try {
    const now = new Date().toISOString();
    const ip = req.headers['x-forwarded-for'] || req.socket.remoteAddress || req.ip;
    // don't print full bodies in prod; print a short preview for debugging
    let bodyPreview = '';
    try {
      if (req.body && Object.keys(req.body).length) {
        const raw = JSON.stringify(req.body);
        bodyPreview = raw.length > 500 ? raw.slice(0, 500) + '... (truncated)' : raw;
      }
    } catch (e) {
      bodyPreview = '[unable to stringify body]';
    }

    console.log(`[REQ] ${now} ${ip} ${req.method} ${req.originalUrl} headers=${JSON.stringify({
      'content-type': req.headers['content-type'],
      authorization: req.headers['authorization'] ? '[REDACTED]' : undefined,
    })} body=${bodyPreview}`);
  } catch (loggerErr) {
    console.warn('Request logger error:', loggerErr);
  }
  next();
});

// ---------- Routes ----------
app.get('/api/parcels-geojson', async (req, res) => {
  try {
    const now = Date.now();

    if (parcelsCache.data && now - parcelsCache.updatedAt < LAYER_TTLS['main-parcels']) {
      res.setHeader('X-Cache', 'HIT');
      if (respondWithCache(req, res, parcelsCache, 'parcels')) return;
      return res.json(parcelsCache.data);
    }

    try {
      const start = Date.now();
      const result = await fetchParcelsFromExternal();
      const took = Date.now() - start;
      res.setHeader('X-Cache', result.fromCache ? 'HIT' : 'MISS');
      res.setHeader('X-Fetch-Time-ms', String(took));
      if (respondWithCache(req, res, parcelsCache, 'parcels')) return;
      return res.json(result.data);
    } catch (fetchErr) {
      console.error('Error fetching parcels, fallback check:', fetchErr.message);
      if (parcelsCache.data) {
        res.setHeader('X-Cache', 'STALE');
        res.setHeader('X-Cache-Age-ms', String(now - parcelsCache.updatedAt));
        if (respondWithCache(req, res, parcelsCache, 'parcels')) return;
        return res.json(parcelsCache.data);
      }
      return res.status(502).json({
        status: 'error',
        error: 'Failed to fetch parcels data from upstream',
        details: fetchErr.message,
      });
    }
  } catch (err) {
    console.error('parcels-geojson handler error:', err.message);
    res.status(500).json({ status: 'error', error: 'Server error', details: err.message });
  }
});

app.get('/api/mahalles', async (req, res) => {
  try {
    const now = Date.now();

    if (mahallesCache.data && now - mahallesCache.updatedAt < LAYER_TTLS['main-mahalles']) {
      res.setHeader('X-Cache', 'HIT');
      if (respondWithCache(req, res, mahallesCache, 'mahalles')) return;
      return res.json(mahallesCache.data);
    }

    try {
      const start = Date.now();
      const result = await fetchMahallesFromExternal();
      const took = Date.now() - start;
      res.setHeader('X-Cache', result.fromCache ? 'HIT' : 'MISS');
      res.setHeader('X-Fetch-Time-ms', String(took));
      if (respondWithCache(req, res, mahallesCache, 'mahalles')) return;
      return res.json(result.data);
    } catch (fetchErr) {
      console.error('Error fetching mahalles, fallback check:', fetchErr.message);
      if (mahallesCache.data) {
        res.setHeader('X-Cache', 'STALE');
        res.setHeader('X-Cache-Age-ms', String(now - mahallesCache.updatedAt));
        if (respondWithCache(req, res, mahallesCache, 'mahalles')) return;
        return res.json(mahallesCache.data);
      }
      return res.status(502).json({
        status: 'error',
        error: 'Failed to fetch mahalles data from upstream',
        details: fetchErr.message,
      });
    }
  } catch (err) {
    console.error('mahalles handler error:', err.message);
    res.status(500).json({ status: 'error', error: 'Server error', details: err.message });
  }
});

// NEW: provide endpoint for mabar layer as read-only external layer
app.get('/api/mabar', async (req, res) => {
  try {
    const now = Date.now();

    if (mabarCache.data && now - mabarCache.updatedAt < LAYER_TTLS['main-mabar']) {
      res.setHeader('X-Cache', 'HIT');
      if (respondWithCache(req, res, mabarCache, 'mabar')) return;
      return res.json(mabarCache.data);
    }

    try {
      const start = Date.now();
      const result = await fetchMabarFromExternal();
      const took = Date.now() - start;
      res.setHeader('X-Cache', result.fromCache ? 'HIT' : 'MISS');
      res.setHeader('X-Fetch-Time-ms', String(took));
      if (respondWithCache(req, res, mabarCache, 'mabar')) return;
      return res.json(result.data);
    } catch (fetchErr) {
      console.error('Error fetching mabar, fallback check:', fetchErr.message);
      if (mabarCache.data) {
        res.setHeader('X-Cache', 'STALE');
        res.setHeader('X-Cache-Age-ms', String(now - mabarCache.updatedAt));
        if (respondWithCache(req, res, mabarCache, 'mabar')) return;
        return res.json(mabarCache.data);
      }
      return res.status(502).json({
        status: 'error',
        error: 'Failed to fetch mabar data from upstream',
        details: fetchErr.message,
      });
    }
  } catch (err) {
    console.error('mabar handler error:', err.message);
    res.status(500).json({ status: 'error', error: 'Server error', details: err.message });
  }
});

app.post('/api/login', async (req, res) => {
  try {
    const { username, password } = req.body;
    if (!username || !password) {
      return res.status(400).json({
        status: 'error',
        error: 'Username and password are required',
      });
    }

    const user = await User.findOne({ username });
    if (!user) {
      return res.status(404).json({ status: 'error', error: 'User not found' });
    }

    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) {
      return res.status(400).json({ status: 'error', error: 'Invalid credentials' });
    }

    const token = jwt.sign(
      { id: user._id, role: user.role, tools: user.tools, layers: user.layers },
      process.env.JWT_SECRET,
      { expiresIn: '1h' }
    );

    res.json({
      status: 'success',
      message: 'Login successful',
      token,
      role: user.role,
      tools: user.tools,
      layers: user.layers,
    });
  } catch (error) {
    res.status(500).json({
      status: 'error',
      error: 'Login failed',
      details: error.message,
    });
  }
});

app.post('/api/register', authMiddleware, adminMiddleware, async (req, res) => {
  try {
    const { username, password, role, tools, layers } = req.body;

    if (!username || !password) {
      return res.status(400).json({
        status: 'error',
        error: 'Username and password are required',
      });
    }

    if (await User.findOne({ username })) {
      return res.status(400).json({
        status: 'error',
        error: 'Username already exists',
      });
    }

    const validTools = [
      'stats',
      'edit',
      'export',
      'spatial',
      'visual',
      'network',
      'join',
      'modeling',
      'draw',
      'filter',
      'search',
    ];
    if (tools && tools.some((tool) => !validTools.includes(tool))) {
      return res.status(400).json({
        status: 'error',
        error: 'Invalid tools provided',
      });
    }

    const hashedPassword = await bcrypt.hash(password, 10);
    const user = new User({
      username,
      password: hashedPassword,
      role: role || 'user',
      tools: tools || [],
      layers: layers || [],
    });

    await user.save();
    res.status(201).json({
      status: 'success',
      message: 'User registered successfully',
      username: user.username,
      user: { tools: user.tools, layers: user.layers },
    });
  } catch (error) {
    res.status(500).json({
      status: 'error',
      error: 'Failed to register user',
      details: error.message,
    });
  }
});

app.get('/api/users', authMiddleware, adminMiddleware, async (req, res) => {
  try {
    const users = await User.find({}).select('-password');
    res.json({
      status: 'success',
      message: 'Users fetched successfully',
      users,
    });
  } catch (error) {
    res.status(500).json({
      status: 'error',
      error: 'Failed to fetch users',
      details: error.message,
    });
  }
});

app.put('/api/users/:id', authMiddleware, adminMiddleware, async (req, res) => {
  try {
    const { role, tools, layers } = req.body;
    const user = await User.findByIdAndUpdate(
      req.params.id,
      { role, tools, layers },
      { new: true }
    ).select('-password');

    if (!user) {
      return res.status(404).json({
        status: 'error',
        error: 'User not found',
      });
    }
    res.json({
      status: 'success',
      message: 'User updated successfully',
      user,
    });
  } catch (error) {
    res.status(500).json({
      status: 'error',
      error: 'Failed to update user',
      details: error.message,
    });
  }
});

app.delete('/api/users/:id', authMiddleware, adminMiddleware, async (req, res) => {
  try {
    const user = await User.findByIdAndDelete(req.params.id);
    if (!user) {
      return res.status(404).json({
        status: 'error',
        error: 'User not found',
      });
    }
    res.json({
      status: 'success',
      message: 'User deleted successfully',
    });
  } catch (error) {
    res.status(500).json({
      status: 'error',
      error: 'Failed to delete user',
      details: error.message,
    });
  }
});

app.get('/api/layers', authMiddleware, async (req, res) => {
  try {
    const { storage } = req.query;
    if (!storage || !['db', 'local'].includes(storage)) {
      return res.status(400).json({
        status: 'error',
        error: "Storage must be 'db' or 'local'",
      });
    }

    let layers = [];
    if (storage === 'db') {
      const dbLayers = await Layer.find({ storage: 'db' });
      layers = dbLayers.map((layer) => ({
        name: layer.name,
        count: layer.data.features?.length || 0,
        storage: 'db',
        data: layer.data,
        color: layer.color,
        version: layer.updatedAt.getTime(),
        updatedAt: layer.updatedAt,
      }));
      try {
        // main-parcels from upstream
        const mainLayerRes = await externalAxios.get('/api/parcels-geojson/');
        if (mainLayerRes.data && mainLayerRes.data.type === 'FeatureCollection') {
          layers.unshift({
            name: 'main-parcels',
            count: mainLayerRes.data.features?.length || 0,
            storage: 'external',
            data: mainLayerRes.data,
            updatedAt: new Date().toISOString(),
          });
        }
      } catch (err) {
        console.error('Failed to fetch main parcels layer:', err.message);
      }
      try {
        // main-mahalles: use upstream mahalles endpoint
        const mainMahallesRes = await externalAxios.get('/api/mahalles');
        if (mainMahallesRes.data && mainMahallesRes.data.results) {
          const features = mainMahallesRes.data.results.map((item) => ({
            type: 'Feature',
            geometry: item.geometry,
            properties: item.properties,
            id: item.id,
          }));
          layers.unshift({
            name: 'main-mahalles',
            count: features.length || 0,
            storage: 'external',
            data: { type: 'FeatureCollection', features },
            updatedAt: new Date().toISOString(),
          });
        } else if (mainMahallesRes.data && mainMahallesRes.data.type === 'FeatureCollection') {
          layers.unshift({
            name: 'main-mahalles',
            count: mainMahallesRes.data.features?.length || 0,
            storage: 'external',
            data: mainMahallesRes.data,
            updatedAt: new Date().toISOString(),
          });
        }
      } catch (err) {
        console.error('Failed to fetch main mahalles layer:', err.message);
      }

      // NEW: try to fetch main-mabar from /mabar-simple/ (read-only external layer)
      try {
        const mainMabarRes = await externalAxios.get('/mabar-simple/');
        if (mainMabarRes.data) {
          // normalize similar to fetchMabarFromExternal: results -> features, featurecollection -> pass through
          let mabarGeo = { type: 'FeatureCollection', features: [] };
          if (mainMabarRes.data.results && Array.isArray(mainMabarRes.data.results)) {
            mabarGeo.features = mainMabarRes.data.results.map((item) => {
              let geometry = item.geometry ?? item.geom ?? null;
              if (item.geometry_json) {
                try {
                  geometry = JSON.parse(item.geometry_json);
                } catch (parseErr) {
                  console.error('Failed to parse geometry_json for item in /api/layers:', parseErr.message);
                }
              }
              if (item.type === 'Feature') return { ...item, geometry };
              return {
                type: 'Feature',
                id: item.id ?? item.properties?.OBJECTID ?? undefined,
                geometry,
                properties: { ...(item.properties || {}), ...(item.extra || {}) },
              };
            });
          } else if (mainMabarRes.data.type === 'FeatureCollection') {
            mabarGeo = { ...mainMabarRes.data };
            mabarGeo.features = mabarGeo.features.map((feature) => {
              let geometry = feature.geometry;
              if (feature.properties?.geometry_json) {
                try {
                  geometry = JSON.parse(feature.properties.geometry_json);
                } catch (parseErr) {
                  console.error('Failed to parse geometry_json in properties in /api/layers:', parseErr.message);
                }
              } else if (feature.geometry_json) {
                try {
                  geometry = JSON.parse(feature.geometry_json);
                } catch (parseErr) {
                  console.error('Failed to parse geometry_json in feature in /api/layers:', parseErr.message);
                }
              }
              return { ...feature, geometry };
            });
          } else if (Array.isArray(mainMabarRes.data)) {
            mabarGeo.features = mainMabarRes.data.map((item) => {
              let geometry = item.geometry ?? item.geom ?? null;
              if (item.geometry_json) {
                try {
                  geometry = JSON.parse(item.geometry_json);
                } catch (parseErr) {
                  console.error('Failed to parse geometry_json for item in /api/layers:', parseErr.message);
                }
              }
              if (item.type === 'Feature') return { ...item, geometry };
              return {
                type: 'Feature',
                id: item.id ?? item.properties?.OBJECTID ?? undefined,
                geometry,
                properties: { ...(item.properties || {}), ...(item.extra || {}) },
              };
            });
          } else {
            // fallback: wrap raw data into a single feature (non-ideal but avoids crashes)
            let geometry = null;
            if (mainMabarRes.data.geometry_json) {
              try {
                geometry = JSON.parse(mainMabarRes.data.geometry_json);
              } catch (parseErr) {
                console.error('Failed to parse geometry_json for raw in /api/layers:', parseErr.message);
              }
            }
            mabarGeo.features = [
              {
                type: 'Feature',
                id: 'mabar_raw_1',
                geometry,
                properties: { raw: mainMabarRes.data },
              },
            ];
          }

          layers.unshift({
            name: 'main-mabar',
            count: mabarGeo.features?.length || 0,
            storage: 'external',
            data: mabarGeo,
            updatedAt: new Date().toISOString(),
          });
        }
      } catch (err) {
        console.error('Failed to fetch main mabar layer:', err.message);
      }
    } else if (storage === 'local') {
      const files = await fs.readdir(DATA_DIR);
      layers = await Promise.all(
        files
          .filter((file) => file.endsWith('.geojson'))
          .map(async (file) => {
            const data = await fs.readFile(path.join(DATA_DIR, file), 'utf8');
            const geojson = JSON.parse(data);
            const stat = await fs.stat(path.join(DATA_DIR, file));
            return {
              name: path.basename(file, '.geojson'),
              count: geojson.features?.length || 0,
              storage: 'local',
              data: geojson,
              version: stat.mtimeMs,
              updatedAt: stat.mtime.toISOString(),
            };
          })
      );
    }

    const accessibleLayers = layers.filter((layer) => {
      if (layer.storage === 'local' || layer.storage === 'external') return true;
      return req.user.role === 'admin' || req.user.layers.includes(layer.name);
    });

    res.json({
      status: 'success',
      message: 'Layers fetched successfully',
      layers: accessibleLayers,
    });
  } catch (error) {
    res.status(500).json({
      status: 'error',
      error: 'Failed to fetch layers',
      details: error.message,
    });
  }
});

const updateFeatureInLayer = async (
  layerName,
  featureId,
  updatedFeature,
  properties,
  key,
  value,
  storage,
  expectedVersion
) => {
  // Returns standardized object:
  // { layer: { name, data, version, updatedAt }, updatedFeature }
  if (storage === 'db') {
    let layer = await Layer.findOne({ name: layerName, storage: 'db' });
    if (!layer) {
      const e = new Error(`Layer ${layerName} not found`);
      e.cause = { status: 404 };
      throw e;
    }

    if (expectedVersion && layer.updatedAt.getTime() > Number(expectedVersion)) {
      const e = new Error('Conflict: layer has been modified on server');
      e.cause = {
        status: 409,
        layer: {
          name: layerName,
          data: layer.data,
          version: layer.updatedAt.getTime(),
          updatedAt: layer.updatedAt.toISOString(),
        },
      };
      throw e;
    }

    const featureIndex = layer.data.features.findIndex(
      (f) => String(f.properties?.OBJECTID ?? f.id ?? '') === String(featureId)
    );
    if (featureIndex === -1) {
      const e = new Error('Feature not found');
      e.cause = { status: 404 };
      throw e;
    }

    if (updatedFeature) {
      layer.data.features[featureIndex].geometry =
        updatedFeature.geometry ?? layer.data.features[featureIndex].geometry;
      layer.data.features[featureIndex].properties = {
        ...layer.data.features[featureIndex].properties,
        ...(updatedFeature.properties || {}),
      };
      if (updatedFeature.id) layer.data.features[featureIndex].id = updatedFeature.id;
    } else if (properties) {
      layer.data.features[featureIndex].properties = {
        ...layer.data.features[featureIndex].properties,
        ...properties,
      };
    } else if (key && value !== undefined) {
      layer.data.features[featureIndex].properties = {
        ...layer.data.features[featureIndex].properties,
        [key]: value,
      };
    } else {
      const e = new Error('No updatedFeature, properties, or key/value provided');
      e.cause = { status: 400 };
      throw e;
    }

    layer.updatedAt = new Date();
    await layer.save();

    const standardized = {
      name: layer.name,
      data: layer.data,
      version: layer.updatedAt.getTime(),
      updatedAt: layer.updatedAt.toISOString(),
    };

    return { layer: standardized, updatedFeature: layer.data.features[featureIndex] };
  } else {
    const filePath = path.join(DATA_DIR, `${layerName}.geojson`);
    let geojson;
    try {
      geojson = JSON.parse(await fs.readFile(filePath, 'utf8'));
    } catch (err) {
      const e = new Error(`Layer ${layerName} not found`);
      e.cause = { status: 404 };
      throw e;
    }

    if (expectedVersion) {
      const stat = await fs.stat(filePath);
      if (stat.mtimeMs > Number(expectedVersion)) {
        const e = new Error('Conflict: layer has been modified on server');
        e.cause = {
          status: 409,
          layer: {
            name: layerName,
            data: geojson,
            version: stat.mtimeMs,
            updatedAt: stat.mtime.toISOString(),
          },
        };
        throw e;
      }
    }

    const featureIndex = geojson.features.findIndex(
      (f) => String(f.properties?.OBJECTID ?? f.id ?? '') === String(featureId)
    );
    if (featureIndex === -1) {
      const e = new Error('Feature not found');
      e.cause = { status: 404 };
      throw e;
    }

    if (updatedFeature) {
      geojson.features[featureIndex].geometry =
        updatedFeature.geometry ?? geojson.features[featureIndex].geometry;
      geojson.features[featureIndex].properties = {
        ...geojson.features[featureIndex].properties,
        ...(updatedFeature.properties || {}),
      };
      if (updatedFeature.id) geojson.features[featureIndex].id = updatedFeature.id;
    } else if (properties) {
      geojson.features[featureIndex].properties = {
        ...geojson.features[featureIndex].properties,
        ...properties,
      };
    } else if (key && value !== undefined) {
      geojson.features[featureIndex].properties = {
        ...geojson.features[featureIndex].properties,
        [key]: value,
      };
    } else {
      const e = new Error('No updatedFeature, properties, or key/value provided');
      e.cause = { status: 400 };
      throw e;
    }

    await fs.writeFile(filePath, JSON.stringify(geojson, null, 2));
    const stat = await fs.stat(filePath);
    const standardized = {
      name: layerName,
      data: geojson,
      version: stat.mtimeMs,
      updatedAt: stat.mtime.toISOString(),
    };

    return {
      layer: standardized,
      updatedFeature: geojson.features[featureIndex],
    };
  }
};

// Updated: Handle geometry updates for main-parcels and main-mahalles
const updateGeometryInMainLayer = async (layerName, featureId, geometry) => {
  const idStr = String(featureId);
  let externalResponse;
  let endpoint;
  let payload;

  if (layerName === 'main-parcels') {
    payload = { parcel_id: Number(idStr), geometry };
    endpoint = '/api/parcel/update-geometry/';
  } else if (layerName === 'main-mahalles') {
    payload = { mahalle_id: Number(idStr), geometry };
    endpoint = `${MAHALLE_PREFIX}/update-geometry/`;
  } else {
    throw new Error(`Unsupported layer for geometry update: ${layerName}`);
  }

  try {
    // Try with trailing slash first, fallback without
    try {
      externalResponse = await externalAxios.post(endpoint, payload, { validateStatus: null });
    } catch (err) {
      console.warn(`External POST failed for ${endpoint}:`, err.message);
      try {
        const fallbackEndpoint = endpoint.endsWith('/') ? endpoint.slice(0, -1) : `${endpoint}/`;
        externalResponse = await externalAxios.post(fallbackEndpoint, payload, { validateStatus: null });
      } catch (err2) {
        console.error(`External POST fallback failed for ${fallbackEndpoint}:`, err2.message);
        throw err2;
      }
    }

    if (externalResponse.status !== 200 || externalResponse.data?.status !== 'success') {
      console.error(`Upstream geometry update failed:`, {
        status: externalResponse.status,
        data: externalResponse.data,
        endpoint,
        payload,
      });
      throw new Error(`Upstream API returned ${externalResponse.status}: ${JSON.stringify(externalResponse.data)}`);
    }

    console.log(`Geometry updated successfully for ${layerName} ${idStr} via ${endpoint}`);
    return externalResponse.data;

  } catch (error) {
    console.error(`Error updating geometry in ${layerName}:`, error.message);
    throw error;
  }
};

app.post('/api/update-feature', authMiddleware, async (req, res) => {
  try {
    const { layerName, updatedFeature, id, properties, key, value, expectedVersion, storage, updates } =
      req.body;

    if (!layerName || (!['db', 'local'].includes(storage) && layerName !== 'main-parcels' && layerName !== 'main-mahalles')) {
      return res.status(400).json({
        status: 'error',
        error: "layerName is required and storage must be 'db' or 'local' for non-main-parcels layers",
      });
    }

    const featureId = id ?? updatedFeature?.properties?.OBJECTID ?? updatedFeature?.id ?? properties?.OBJECTID;
    if (!featureId && layerName !== 'main-parcels' && layerName !== 'main-mahalles') {
      return res.status(400).json({
        status: 'error',
        error: 'Feature ID (object_id or id) is required for non-main-parcels layers',
      });
    }

    if (
      req.user.role !== 'admin' &&
      req.user.role !== 'editor' &&
      !req.user.layers.includes(layerName)
    ) {
      return res.status(403).json({
        status: 'error',
        error: `Access denied to layer ${layerName}`,
      });
    }

    // NEW: Handle geometry updates for main-parcels and main-mahalles
    if ((layerName === 'main-parcels' || layerName === 'main-mahalles') && updatedFeature?.geometry) {
      try {
        const geometryResponse = await updateGeometryInMainLayer(layerName, featureId, updatedFeature.geometry);
        
        // Refresh local cache immediately
        let updatedLayerData = null;
        try {
          if (layerName === 'main-parcels') {
            parcelsCache.updatedAt = 0; // force refresh
            const refreshed = await fetchParcelsFromExternal().catch(() => null);
            updatedLayerData = refreshed?.data ?? parcelsCache.data;
          } else if (layerName === 'main-mahalles') {
            mahallesCache.updatedAt = 0;
            const refreshed = await fetchMahallesFromExternal().catch(() => null);
            updatedLayerData = refreshed?.data ?? mahallesCache.data;
          }
        } catch (refreshErr) {
          console.error('Failed to refresh main layer after geometry update:', refreshErr.message);
        }

        // Notify clients
        try {
          io.emit('layerUpdated', { layerName, updatedAt: new Date().toISOString() });
        } catch (e) {
          console.warn('Socket emit failed:', e);
        }

        // Send to fake-sync
        await sendToFakeSync('update_geometry', layerName, {
          [layerName === 'main-parcels' ? 'parcel_id' : 'mahalle_id']: featureId,
          geometry: updatedFeature.geometry,
        }).catch(() => {});

        return res.json({
          status: 'success',
          message: 'Geometry updated successfully in main layer',
          feature: { ...updatedFeature, geometry: updatedFeature.geometry },
          layer: {
            name: layerName,
            data: updatedLayerData,
            version: Date.now(),
            updatedAt: new Date().toISOString(),
          },
        });
      } catch (error) {
        console.error('Geometry update error:', error.message);
        return res.status(500).json({
          status: 'error',
          error: `Failed to update geometry in ${layerName}: ${error.message}`,
        });
      }
    }

    // ORIGINAL: Handle property updates for main-parcels and main-mahalles
    if (layerName === 'main-parcels' || layerName === 'main-mahalles') {
      const idStr = String(featureId);
      let results = [];
      let updatedLayerData = null;

      if (updates && typeof updates === 'object' && !Array.isArray(updates)) {
        if (Object.keys(updates).length === 0) {
          return res.status(400).json({
            status: 'error',
            error: 'updates object is empty',
          });
        }

        const limit = pLimit(8);
        const entries = Object.entries(updates);

        const tasks = entries.map(([k, v]) =>
          limit(async () => {
            const start = Date.now();
            try {
              // choose payload & endpoint depending on layerName
              if (layerName === 'main-parcels') {
                const externalResponse = await externalAxios.post('/api/update-feature/', {
                  parcel_id: idStr,
                  key: k,
                  value: v,
                }, { validateStatus: null });

                console.log(`external parcels update key=${k} took ${Date.now() - start}ms`);

                if (externalResponse.status !== 200 || externalResponse.data?.status !== 'success') {
                  return {
                    key: k,
                    status: 'failed',
                    details: externalResponse.data || { status: externalResponse.status },
                  };
                } else {
                  await sendToFakeSync('update_property', layerName, {
                    parcel_id: idStr,
                    key: k,
                    value: v,
                  });
                  return {
                    key: k,
                    status: 'success',
                    feature: externalResponse.data.feature || null,
                  };
                }
              } else {
                // main-mahalles -> use mahalle/update-feature/
                const externalResponse = await externalAxios.post(`${MAHALLE_PREFIX}/update-feature/`, {
                  mahalle_id: idStr,
                  key: k,
                  value: v,
                }, { validateStatus: null });

                console.log(`external mahalles update key=${k} took ${Date.now() - start}ms`);

                if (externalResponse.status !== 200 || externalResponse.data?.status !== 'success') {
                  return {
                    key: k,
                    status: 'failed',
                    details: externalResponse.data || { status: externalResponse.status },
                  };
                } else {
                  await sendToFakeSync('update_property', layerName, {
                    mahalle_id: idStr,
                    key: k,
                    value: v,
                  });
                  return {
                    key: k,
                    status: 'success',
                    feature: externalResponse.data.feature || null,
                  };
                }
              }
            } catch (extErr) {
              console.error(`External update error for key=${k}:`, extErr.message);
              return {
                key: k,
                status: 'error',
                error: extErr.message,
                details: extErr.response?.data || null,
              };
            }
          })
        );

        results = await Promise.all(tasks);
      } else if (key && value !== undefined) {
        try {
          if (layerName === 'main-parcels') {
            const externalResponse = await externalAxios.post('/api/update-feature/', {
              parcel_id: idStr,
              key,
              value,
            }, { validateStatus: null });

            if (externalResponse.data?.status !== 'success') {
              return res.status(400).json({
                status: 'error',
                error: 'Failed to update property in main layer',
                details: externalResponse.data,
              });
            }

            results.push({
              key,
              status: 'success',
              feature: externalResponse.data.feature || null,
            });
            await sendToFakeSync('update_property', 'main-parcels', {
              parcel_id: idStr,
              key,
              value,
            });
          } else {
            // main-mahalles
            const externalResponse = await externalAxios.post(`${MAHALLE_PREFIX}/update-feature/`, {
              mahalle_id: idStr,
              key,
              value,
            }, { validateStatus: null });

            if (externalResponse.data?.status !== 'success') {
              return res.status(400).json({
                status: 'error',
                error: 'Failed to update property in main-mahalles',
                details: externalResponse.data,
              });
            }

            results.push({
              key,
              status: 'success',
              feature: externalResponse.data.feature || null,
            });
            await sendToFakeSync('update_property', 'main-mahalles', {
              mahalle_id: idStr,
              key,
              value,
            });
          }
        } catch (extErr) {
          console.error(`External update error for key=${key}:`, extErr.message);
          return res.status(500).json({
            status: 'error',
            error: 'Failed to update property in main layer',
            details: extErr.message,
          });
        }
      } else {
        return res.status(400).json({
          status: 'error',
          error: 'parcel_id/mahalle_id and either `key`+`value` or `updates` object are required for main layers',
        });
      }

      // Invalidate and refresh local cache immediately (best-effort)
      try {
        if (layerName === 'main-parcels') {
          parcelsCache.updatedAt = 0; // force next fetch to go upstream
          const refreshed = await fetchParcelsFromExternal().catch(() => null);
          if (refreshed?.data) {
            updatedLayerData = refreshed.data;
          } else if (parcelsCache.data) {
            updatedLayerData = parcelsCache.data;
          }
        } else if (layerName === 'main-mahalles') {
          mahallesCache.updatedAt = 0;
          const refreshed = await fetchMahallesFromExternal().catch(() => null);
          if (refreshed?.data) {
            updatedLayerData = refreshed.data;
          } else if (mahallesCache.data) {
            updatedLayerData = mahallesCache.data;
          }
        }
      } catch (refreshErr) {
        console.error('Failed to refresh main layer:', refreshErr.message);
      }

      // notify clients immediately
      try {
        io.emit('layerUpdated', { layerName, updatedAt: new Date().toISOString() });
      } catch (e) {
        console.warn('Socket emit failed:', e);
      }

      const failed = results.filter((r) => r.status !== 'success');
      if (failed.length > 0) {
        return res.status(207).json({
          status: 'partial',
          message: 'Some properties updated, some failed',
          results,
          layer: {
            name: layerName,
            data: updatedLayerData,
            updatedAt: new Date().toISOString(),
          },
        });
      }

      return res.json({
        status: 'success',
        message: 'Properties updated successfully in main layer',
        results,
        layer: {
          name: layerName,
          data: updatedLayerData,
          updatedAt: new Date().toISOString(),
        },
      });
    } else {
      // Original logic for DB/local layers
      try {
        const { layer, updatedFeature: updated } = await updateFeatureInLayer(
          layerName,
          featureId,
          updatedFeature,
          properties,
          key,
          value,
          storage,
          expectedVersion
        );
        await sendToFakeSync('update_feature', layerName, updated);
        io.emit('layerUpdated', { layerName, updatedAt: new Date().toISOString() });

        return res.json({
          status: 'success',
          message: 'Feature updated successfully',
          feature: updated,
          layer,
        });
      } catch (error) {
        if (error.cause?.status) {
          return res.status(error.cause.status).json({
            status: 'error',
            error: error.message,
            layer: error.cause.layer,
          });
        }
        throw error;
      }
    }
  } catch (error) {
    console.error('Update feature error:', error.stack || error.message);
    res.status(500).json({
      status: 'error',
      error: 'Failed to update feature',
      details: error.message,
    });
  }
});

app.post('/api/add-feature', authMiddleware, async (req, res) => {
  try {
    const { layerName, newFeature, storage, expectedVersion } = req.body;
    if (!layerName || !newFeature || !newFeature.properties?.OBJECTID || !['db', 'local'].includes(storage)) {
      return res.status(400).json({
        status: 'error',
        error: 'layerName, newFeature, OBJECTID, and storage are required',
      });
    }

    // permission: match update-feature (admin | editor | layer in user's layers)
    if (
      req.user.role !== 'admin' &&
      req.user.role !== 'editor' &&
      !req.user.layers.includes(layerName)
    ) {
      return res.status(403).json({
        status: 'error',
        error: 'Access denied to this layer',
      });
    }

    const featureId = String(newFeature.properties?.OBJECTID ?? newFeature.id);
    if (!featureId) {
      return res.status(400).json({ status: 'error', error: 'Invalid feature id' });
    }

    // DB-backed storage
    if (storage === 'db') {
      let layer = await Layer.findOne({ name: layerName, storage: 'db' });

      // create layer if not exists and add feature
      if (!layer) {
        layer = new Layer({
          name: layerName,
          data: { type: 'FeatureCollection', features: [newFeature] },
          storage: 'db',
        });
        layer.updatedAt = new Date();
        await layer.save();

        const responseLayer = makeLayerResponse(layer, 'db');
        await sendToFakeSync('add_feature', layerName, newFeature);
        io.emit('layerUpdated', { layerName, updatedAt: new Date().toISOString() });

        return res.status(201).json({
          status: 'success',
          message: 'Feature added successfully (new layer created)',
          layer: responseLayer,
          feature: newFeature,
        });
      }

      // if feature exists -> delegate to updateFeatureInLayer (same behavior as update)
      const existsIndex = layer.data.features.findIndex(
        (f) => String(f.properties?.OBJECTID ?? f.id ?? '') === featureId
      );

      if (existsIndex !== -1) {
        try {
          const { layer: standardized, updatedFeature } = await updateFeatureInLayer(
            layerName,
            featureId,
            newFeature, // use incoming feature as updatedFeature
            null,
            null,
            undefined,
            'db',
            expectedVersion
          );

          await sendToFakeSync('update_feature', layerName, updatedFeature);
          io.emit('layerUpdated', { layerName, updatedAt: new Date().toISOString() });

          return res.json({
            status: 'success',
            message: 'Feature existed and was updated',
            feature: updatedFeature,
            layer: standardized,
          });
        } catch (err) {
          if (err.cause?.status) {
            return res.status(err.cause.status).json({
              status: 'error',
              error: err.message,
              layer: err.cause.layer,
            });
          }
          throw err;
        }
      }

      // feature not exists -> add it
      layer.data.features.push(newFeature);
      layer.updatedAt = new Date();
      await layer.save();

      const responseLayer = makeLayerResponse(layer, 'db');
      await sendToFakeSync('add_feature', layerName, newFeature);
      io.emit('layerUpdated', { layerName, updatedAt: new Date().toISOString() });

      return res.status(201).json({
        status: 'success',
        message: 'Feature added successfully',
        layer: responseLayer,
        feature: newFeature,
      });
    }

    // Local file-backed storage
    const filePath = path.join(DATA_DIR, `${layerName}.geojson`);
    let geojson;
    try {
      geojson = JSON.parse(await fs.readFile(filePath, 'utf8'));
    } catch (err) {
      // if file doesn't exist -> create it with the new feature
      if (err.code === 'ENOENT') {
        const newGeo = { type: 'FeatureCollection', features: [newFeature] };
        await fs.writeFile(filePath, JSON.stringify(newGeo, null, 2));
        const stat = await fs.stat(filePath);
        const responseLayer = { name: layerName, data: newGeo, version: stat.mtimeMs, updatedAt: stat.mtime.toISOString() };

        await sendToFakeSync('add_feature', layerName, newFeature);
        io.emit('layerUpdated', { layerName, updatedAt: new Date().toISOString() });

        return res.status(201).json({
          status: 'success',
          message: 'Feature added successfully (new local layer created)',
          layer: responseLayer,
          feature: newFeature,
        });
      }
      throw err;
    }

    const featureIndex = geojson.features.findIndex(
      (f) => String(f.properties?.OBJECTID ?? f.id ?? '') === featureId
    );

    if (featureIndex !== -1) {
      // existing -> reuse updateFeatureInLayer for consistency
      try {
        const { layer: standardized, updatedFeature } = await updateFeatureInLayer(
          layerName,
          featureId,
          newFeature,
          null,
          null,
          undefined,
          'local',
          expectedVersion
        );

        await sendToFakeSync('update_feature', layerName, updatedFeature);
        io.emit('layerUpdated', { layerName, updatedAt: new Date().toISOString() });

        return res.json({
          status: 'success',
          message: 'Feature existed and was updated',
          feature: updatedFeature,
          layer: standardized,
        });
      } catch (err) {
        if (err.cause?.status) {
          return res.status(err.cause.status).json({
            status: 'error',
            error: err.message,
            layer: err.cause.layer,
          });
        }
        throw err;
      }
    }

    // not exists -> add and save file
    geojson.features.push(newFeature);
    await fs.writeFile(filePath, JSON.stringify(geojson, null, 2));
    const stat = await fs.stat(filePath);
    const responseLayer = { name: layerName, data: geojson, version: stat.mtimeMs, updatedAt: stat.mtime.toISOString() };

    await sendToFakeSync('add_feature', layerName, newFeature);
    io.emit('layerUpdated', { layerName, updatedAt: new Date().toISOString() });

    return res.status(201).json({
      status: 'success',
      message: 'Feature added successfully',
      layer: responseLayer,
      feature: newFeature,
    });
  } catch (error) {
    console.error('Add feature error:', error.stack || error.message);
    res.status(500).json({
      status: 'error',
      error: 'Failed to add feature',
      details: error.message,
    });
  }
});

/* ----------------------------------------------------------------------
   New: MAHALLE endpoints that mirror main-parcels behavior:
   - POST /api/mahalle/update-feature/
   - POST /api/mahalle/delete-feature/
   - POST /api/mahalle/add-feature/
   These endpoints expect payload:
     - mahalle_id === OBJECTID (stringable)
     - for add/update: key + value   OR updates object
     - for delete: key (no value required)
   ---------------------------------------------------------------------- */

// MAHALLE: update-feature (behaves like main-parcels /api/update-feature for parcels)
app.post('/api/mahalle/update-feature/', authMiddleware, async (req, res) => {
  try {
    const { mahalle_id, key, value, updates } = req.body;

    if (!mahalle_id) {
      return res.status(400).json({ status: 'error', error: 'mahalle_id is required' });
    }

    if (!updates && (key === undefined || value === undefined)) {
      return res.status(400).json({
        status: 'error',
        error: 'Either `updates` (object) or `key`+`value` must be provided',
      });
    }

    // permission: admin | editor | user.layers contains main-mahalles
    if (
      req.user.role !== 'admin' &&
      req.user.role !== 'editor' &&
      !req.user.layers.includes('main-mahalles')
    ) {
      return res.status(403).json({ status: 'error', error: 'Access denied to main-mahalles layer' });
    }

    const idStr = String(mahalle_id);
    const results = [];
    let updatedLayerData = null;

    if (updates && typeof updates === 'object' && !Array.isArray(updates)) {
      if (Object.keys(updates).length === 0) {
        return res.status(400).json({ status: 'error', error: 'updates object is empty' });
      }

      const limit = pLimit(8);
      const entries = Object.entries(updates);

      const tasks = entries.map(([k, v]) =>
        limit(async () => {
          const start = Date.now();
          try {
            const externalResponse = await externalAxios.post(`${MAHALLE_PREFIX}/update-feature/`, {
              mahalle_id: idStr,
              key: k,
              value: v,
            }, { validateStatus: null });

            console.log(`external mahalle update key=${k} took ${Date.now() - start}ms`);

            if (externalResponse.status !== 200 || externalResponse.data?.status !== 'success') {
              return {
                key: k,
                status: 'failed',
                details: externalResponse.data || { status: externalResponse.status },
              };
            } else {
              await sendToFakeSync('update_property', 'main-mahalles', {
                mahalle_id: idStr,
                key: k,
                value: v,
              }).catch(() => {});
              return {
                key: k,
                status: 'success',
                feature: externalResponse.data.feature || null,
              };
            }
          } catch (extErr) {
            console.error(`External mahalle update error for key=${k}:`, extErr.message);
            return { key: k, status: 'error', error: extErr.message, details: extErr.response?.data || null };
          }
        })
      );

      const all = await Promise.all(tasks);
      results.push(...all);
    } else {
      // single key/value
      try {
        const externalResponse = await externalAxios.post(`${MAHALLE_PREFIX}/update-feature/`, {
          mahalle_id: idStr,
          key,
          value,
        }, { validateStatus: null });

        if (externalResponse.status !== 200 || externalResponse.data?.status !== 'success') {
          return res.status(400).json({
            status: 'error',
            error: 'Failed to update property in mahalle',
            details: externalResponse.data,
          });
        }

        results.push({ key, status: 'success', feature: externalResponse.data.feature || null });
        await sendToFakeSync('update_property', 'main-mahalles', { mahalle_id: idStr, key, value }).catch(() => {});
      } catch (extErr) {
        console.error('External mahalle update error:', extErr.message);
        return res.status(500).json({ status: 'error', error: 'Failed to update mahalle property', details: extErr.message });
      }
    }

    // invalidate & refresh cache best-effort
    try {
      mahallesCache.updatedAt = 0;
      const refreshed = await fetchMahallesFromExternal().catch(() => null);
      updatedLayerData = refreshed?.data ?? mahallesCache.data;
    } catch (refreshErr) {
      console.warn('Failed to refresh mahalles after update:', refreshErr.message);
    }

    // notify clients
    try { io.emit('layerUpdated', { layerName: 'main-mahalles', updatedAt: new Date().toISOString() }); } catch(e){}

    const failed = results.filter((r) => r.status !== 'success');
    if (failed.length > 0) {
      return res.status(207).json({
        status: 'partial',
        message: 'Some properties updated, some failed',
        results,
        layer: { name: 'main-mahalles', data: updatedLayerData, updatedAt: new Date().toISOString() },
      });
    }

    return res.json({
      status: 'success',
      message: 'Properties updated successfully in main-mahalles',
      results,
      layer: { name: 'main-mahalles', data: updatedLayerData, updatedAt: new Date().toISOString() },
    });
  } catch (err) {
    console.error('mahalle update-feature handler error:', err.stack || err.message);
    res.status(500).json({ status: 'error', error: 'Server error', details: err.message });
  }
});

// MAHALLE: delete-feature (behaves like delete-parcel-property but for mahalles)
app.post('/api/mahalle/delete-feature/', authMiddleware, async (req, res) => {
  try {
    const { mahalle_id, key } = req.body;
    if (!mahalle_id || !key) {
      return res.status(400).json({ status: 'error', error: 'mahalle_id and key are required' });
    }

    // permission
    if (
      req.user.role !== 'admin' &&
      req.user.role !== 'editor' &&
      !req.user.layers.includes('main-mahalles')
    ) {
      return res.status(403).json({ status: 'error', error: 'Access denied to main-mahalles layer' });
    }

    const payload = { mahalle_id: String(mahalle_id), key };

    // attempt external (with trailing slash, fallback)
    let externalResponse;
    try {
      externalResponse = await externalAxios.post(`${MAHALLE_PREFIX}/delete-feature/`, payload, { validateStatus: null });
    } catch (err) {
      console.warn('externalAxios POST failed for mahalle delete-feature:', err.message);
      try {
        externalResponse = await externalAxios.post(`${MAHALLE_PREFIX}/delete-feature`, payload, { validateStatus: null });
      } catch (err2) {
        console.error('externalAxios DELETE fallback failed:', err2.message);
        return res.status(502).json({ status: 'error', error: 'Failed to contact upstream delete-feature API', details: err2.message });
      }
    }

    if (externalResponse.status !== 200 || externalResponse.data?.status !== 'success') {
      const statusToReturn = externalResponse.status && externalResponse.status >= 400 ? externalResponse.status : 502;
      return res.status(statusToReturn).json({
        status: 'error',
        error: 'Failed to delete property via upstream mahalle API',
        upstream: { status: externalResponse.status, data: externalResponse.data },
      });
    }

    // refresh cache best-effort
    try {
      const refreshResp = await externalAxios.get('/api/mahalles', { validateStatus: null });
      if (refreshResp?.data) {
        let geojsonData = { type: 'FeatureCollection', features: [] };
        if (refreshResp.data.results && Array.isArray(refreshResp.data.results)) {
          geojsonData.features = refreshResp.data.results.map((item) => ({
            type: 'Feature',
            id: item.id,
            geometry: item.geometry,
            properties: item.properties,
          }));
        } else if (refreshResp.data.type === 'FeatureCollection') {
          geojsonData = refreshResp.data;
        }
        mahallesCache.data = geojsonData;
        mahallesCache.updatedAt = Date.now();
        writeMahallesToFile(geojsonData).catch(() => {});
      }
    } catch (refreshErr) {
      console.warn('Failed to refresh mahalles after delete:', refreshErr.message);
    }

    await sendToFakeSync('delete_property', 'main-mahalles', payload).catch(() => {});
    try { io.emit('layerUpdated', { layerName: 'main-mahalles', updatedAt: new Date().toISOString() }); } catch(e){}

    return res.json({
      status: 'success',
      message: 'Property deleted successfully (mahalle)',
      feature: externalResponse.data.feature || null,
      layer: { name: 'main-mahalles', data: mahallesCache.data, updatedAt: new Date().toISOString() },
    });
  } catch (error) {
    console.error('mahalle delete-feature handler error:', error.stack || error.message);
    res.status(500).json({ status: 'error', error: 'Failed to delete property', details: error.message });
  }
});

// MAHALLE: add-feature (behaves like add-parcel-property / add-feature for parcels)
app.post('/api/mahalle/add-feature/', authMiddleware, async (req, res) => {
  try {
    const { mahalle_id, key, value } = req.body;
    if (!mahalle_id || !key || value === undefined) {
      return res.status(400).json({ status: 'error', error: 'mahalle_id, key and value are required' });
    }

    // permission
    if (
      req.user.role !== 'admin' &&
      req.user.role !== 'editor' &&
      !req.user.layers.includes('main-mahalles')
    ) {
      return res.status(403).json({ status: 'error', error: 'Access denied to main-mahalles layer' });
    }

    const payload = { mahalle_id: String(mahalle_id), key, value };

    let externalResponse;
    try {
      externalResponse = await externalAxios.post(`${MAHALLE_PREFIX}/add-feature/`, payload, { validateStatus: null });
    } catch (err) {
      console.warn('externalAxios POST failed for mahalle add-feature:', err.message);
      try {
        externalResponse = await externalAxios.post(`${MAHALLE_PREFIX}/add-feature`, payload, { validateStatus: null });
      } catch (err2) {
        console.error('externalAxios add-feature fallback failed:', err2.message);
        return res.status(502).json({ status: 'error', error: 'Failed to contact upstream add-feature API', details: err2.message });
      }
    }

    if (externalResponse.status !== 200 || externalResponse.data?.status !== 'success') {
      const statusToReturn = externalResponse.status && externalResponse.status >= 400 ? externalResponse.status : 502;
      return res.status(statusToReturn).json({
        status: 'error',
        error: 'Failed to add property to upstream mahalle API',
        upstream: { status: externalResponse.status, data: externalResponse.data },
      });
    }

    // refresh cache best-effort
    try {
      const refreshResp = await externalAxios.get('/api/mahalles', { validateStatus: null });
      if (refreshResp?.data) {
        let geojsonData = { type: 'FeatureCollection', features: [] };
        if (refreshResp.data.results && Array.isArray(refreshResp.data.results)) {
          geojsonData.features = refreshResp.data.results.map((item) => ({
            type: 'Feature',
            id: item.id,
            geometry: item.geometry,
            properties: item.properties,
          }));
        } else if (refreshResp.data.type === 'FeatureCollection') {
          geojsonData = refreshResp.data;
        }
        mabarCache.data = geojsonData;
        mabarCache.updatedAt = Date.now();
        writeMabarToFile(geojsonData).catch(() => {});
      }
    } catch (refreshErr) {
      console.warn('Failed to refresh mahalles after add:', refreshErr.message);
    }

    await sendToFakeSync('add_property', 'main-mahalles', payload).catch(() => {});
    try { io.emit('layerUpdated', { layerName: 'main-mahalles', updatedAt: new Date().toISOString() }); } catch(e){}

    return res.json({
      status: 'success',
      message: 'Property added successfully (mahalle)',
      feature: externalResponse.data.feature || null,
      layer: { name: 'main-mahalles', data: mabarCache.data, updatedAt: new Date().toISOString() },
    });
  } catch (error) {
    console.error('mahalle add-feature handler error:', error.stack || error.message);
    res.status(500).json({ status: 'error', error: 'Failed to add property', details: error.message });
  }
});

/* ----------------------------------------------------------------------
   End of MAHALLE endpoints
   ---------------------------------------------------------------------- */

app.post('/api/force-update-layers', authMiddleware, async (req, res) => {
  try {
    const { layers, delta, action, expectedVersions, storage } = req.body;

    if (!['db', 'local'].includes(storage)) {
      return res.status(400).json({
        status: 'error',
        error: "Storage must be 'db' or 'local'",
      });
    }

    if (delta && typeof delta === 'object' && action) {
      if (!expectedVersions) {
        return res.status(400).json({
          status: 'error',
          error: 'expectedVersions required for delta',
        });
      }

      const updated = [];
      const conflicts = [];

      for (const [layerName, changes] of Object.entries(delta)) {
        if (!changes || !layerName) continue;

        if (req.user.role !== 'admin' && !req.user.layers.includes(layerName)) {
          return res.status(403).json({
            status: 'error',
            error: `Access denied to layer ${layerName}`,
          });
        }

        if (storage === 'db') {
          let layer = await Layer.findOne({ name: layerName, storage: 'db' });
          if (!layer) {
            return res.status(404).json({
              status: 'error',
              error: `Layer ${layerName} not found`,
            });
          }

          const currentVersion = layer.updatedAt.getTime();
          if (expectedVersions[layerName] && currentVersion > Number(expectedVersions[layerName])) {
            conflicts.push({ name: layerName, version: currentVersion });
            continue;
          }

          const featureMap = new Map(
            layer.data.features.map((f) => [String(f.properties?.OBJECTID ?? f.id), f])
          );

          if (Array.isArray(changes.removed)) {
            changes.removed.forEach((id) => featureMap.delete(String(id)));
          }

          if (Array.isArray(changes.updated)) {
            changes.updated.forEach((updatedFeature) => {
              const id = updatedFeature.properties?.OBJECTID || updatedFeature.id;
              if (id) featureMap.set(String(id), updatedFeature);
            });
          }

          if (Array.isArray(changes.added)) {
            changes.added.forEach((newFeature) => {
              const id = newFeature.properties?.OBJECTID || newFeature.id;
              featureMap.set(String(id || `temp_${Date.now()}`), newFeature);
            });
          }

          layer.data.features = Array.from(featureMap.values());
          layer.updatedAt = new Date();
          await layer.save();
          await sendToFakeSync(action, layerName, changes);
          io.emit('layerUpdated', { layerName, updatedAt: new Date().toISOString() });
          updated.push(layerName);
        } else {
          const filePath = path.join(DATA_DIR, `${layerName}.geojson`);
          let geojson;
          try {
            geojson = JSON.parse(await fs.readFile(filePath, 'utf8'));
          } catch (err) {
            if (err.code === 'ENOENT') {
              return res.status(404).json({
                status: 'error',
                error: `Layer ${layerName} not found`,
              });
            }
            throw err;
          }

          const stat = await fs.stat(filePath);
          const currentVersion = stat.mtimeMs;
          if (expectedVersions[layerName] && currentVersion > Number(expectedVersions[layerName])) {
            conflicts.push({ name: layerName, version: currentVersion });
            continue;
          }

          const featureMap = new Map(
            geojson.features.map((f) => [String(f.properties?.OBJECTID ?? f.id), f])
          );

          if (Array.isArray(changes.removed)) {
            changes.removed.forEach((id) => featureMap.delete(String(id)));
          }

          if (Array.isArray(changes.updated)) {
            changes.updated.forEach((updatedFeature) => {
              const id = updatedFeature.properties?.OBJECTID || updatedFeature.id;
              if (id) featureMap.set(String(id), updatedFeature);
            });
          }

          if (Array.isArray(changes.added)) {
            changes.added.forEach((newFeature) => {
              const id = newFeature.properties?.OBJECTID || newFeature.id;
              featureMap.set(String(id || `temp_${Date.now()}`), newFeature);
            });
          }

          geojson.features = Array.from(featureMap.values());
          const backupPath = `${filePath}.bak.${Date.now()}`;
          await fs.copyFile(filePath, backupPath);
          await fs.writeFile(filePath, JSON.stringify(geojson, null, 2));
          await sendToFakeSync(action, layerName, changes);
          io.emit('layerUpdated', { layerName, updatedAt: new Date().toISOString() });
          updated.push(layerName);
        }
      }

      if (conflicts.length > 0) {
        return res.status(409).json({
          status: 'error',
          error: 'Conflicts in some layers',
          conflicts,
          updated,
        });
      }

      return res.json({
        status: 'success',
        message: 'Layers updated successfully',
        updated,
        action,
      });
    }

    if (!Array.isArray(layers) || layers.length === 0) {
      return res.status(400).json({
        status: 'error',
        error: 'layers array required',
      });
    }

    const updated = [];
    const conflicts = [];

    for (const layer of layers) {
      if (!layer.name || !layer.data) continue;

      if (storage === 'db') {
        let dbLayer = await Layer.findOne({ name: layer.name, storage: 'db' });
        if (
          layer.version &&
          dbLayer &&
          dbLayer.updatedAt.getTime() > Number(layer.version) &&
          !layer.force
        ) {
          conflicts.push({
            name: layer.name,
            data: dbLayer.data,
            version: dbLayer.updatedAt.getTime(),
            updatedAt: dbLayer.updatedAt.toISOString(),
          });
          continue;
        }

        if (!dbLayer) {
          dbLayer = new Layer({
            name: layer.name,
            data: layer.data,
            storage: 'db',
          });
        } else {
          dbLayer.data = layer.data;
          dbLayer.updatedAt = new Date();
        }
        await dbLayer.save();
        await sendToFakeSync('update_layer', layer.name, layer.data);
        io.emit('layerUpdated', { layerName: layer.name, updatedAt: new Date().toISOString() });
        updated.push(layer.name);
      } else {
        const filePath = path.join(DATA_DIR, `${layer.name}.geojson`);
        try {
          const stat = await fs.stat(filePath);
          if (
            layer.version &&
            stat.mtimeMs > Number(layer.version) &&
            !force &&
            !layer.force
          ) {
            const currentContent = await fs.readFile(filePath, 'utf8');
            conflicts.push({
              name: layer.name,
              data: JSON.parse(currentContent),
              version: stat.mtimeMs,
              updatedAt: stat.mtime.toISOString(),
            });
            continue;
          }
        } catch (err) {
          if (err.code !== 'ENOENT') throw err;
        }

        try {
          await fs.stat(filePath);
          const backupPath = `${filePath}.bak.${Date.now()}`;
          await fs.copyFile(filePath, backupPath);
        } catch (err) {
          if (err.code !== 'ENOENT') throw err;
        }

        await fs.writeFile(filePath, JSON.stringify(layer.data, null, 2));
        await sendToFakeSync('update_layer', layer.name, layer.data);
        io.emit('layerUpdated', { layerName: layer.name, updatedAt: new Date().toISOString() });
        updated.push(layer.name);
      }
    }

    if (conflicts.length > 0) {
      return res.status(409).json({
        status: 'error',
        error: 'Conflict: some layers have been modified on server',
        conflicts,
        updated,
      });
    }

    res.json({
      status: 'success',
      message: 'Layers updated successfully',
      updated,
    });
  } catch (error) {
    res.status(500).json({
      status: 'error',
      error: 'Failed to force update layers',
      details: error.message,
    });
  }
});

app.post('/api/delete-feature', authMiddleware, async (req, res) => {
  try {
    const { layerName, featureId, storage } = req.body;
    if (!layerName || featureId == null || !['db', 'local'].includes(storage)) {
      return res.status(400).json({
        status: 'error',
        error: 'layerName, featureId, and storage are required',
      });
    }

    if (req.user.role !== 'admin' && !req.user.layers.includes(layerName)) {
      return res.status(403).json({
        status: 'error',
        error: 'Access denied to this layer',
      });
    }

    if (storage === 'db') {
      let layer = await Layer.findOne({ name: layerName, storage: 'db' });
      if (!layer) {
        return res.status(404).json({
          status: 'error',
          error: `Layer ${layerName} not found`,
        });
      }

      const originalLength = layer.data.features.length;
      layer.data.features = layer.data.features.filter(
        (f) => String(f.properties?.OBJECTID ?? f.id ?? '') !== String(featureId)
      );

      if (layer.data.features.length === originalLength) {
        return res.status(404).json({ status: 'error', error: 'Feature not found' });
      }

      layer.updatedAt = new Date();
      await layer.save();
      await sendToFakeSync('delete_feature', layerName, { featureId });
      io.emit('layerUpdated', { layerName, updatedAt: new Date().toISOString() });
      res.json({ status: 'success', message: 'Feature deleted successfully' });
    } else {
      const filePath = path.join(DATA_DIR, `${layerName}.geojson`);
      let geojson;
      try {
        geojson = JSON.parse(await fs.readFile(filePath, 'utf8'));
      } catch (error) {
        if (error.code === 'ENOENT') {
          return res.status(404).json({
            status: 'error',
            error: `Layer ${layerName}.geojson not found`,
          });
        }
        throw error;
      }

      const originalLength = geojson.features.length;
      geojson.features = geojson.features.filter(
        (f) => String(f.properties?.OBJECTID ?? f.id ?? '') !== String(featureId)
      );

      if (geojson.features.length === originalLength) {
        return res.status(404).json({ status: 'error', error: 'Feature not found' });
      }

      await fs.writeFile(filePath, JSON.stringify(geojson, null, 2));
      await sendToFakeSync('delete_feature', layerName, { featureId });
      io.emit('layerUpdated', { layerName, updatedAt: new Date().toISOString() });
      res.json({ status: 'success', message: 'Feature deleted successfully' });
    }
  } catch (error) {
    res.status(500).json({
      status: 'error',
      error: 'Failed to delete feature',
      details: error.message,
    });
  }
});

app.delete('/api/delete-layer', authMiddleware, adminMiddleware, async (req, res) => {
  try {
    const { layerName, storage } = req.body;
    if (!layerName || !['db', 'local'].includes(storage)) {
      return res.status(400).json({
        status: 'error',
        error: 'layerName and storage are required',
      });
    }

    if (storage === 'db') {
      const layer = await Layer.findOneAndDelete({ name: layerName, storage: 'db' });
      if (!layer) {
        return res.status(404).json({
          status: 'error',
          error: `Layer ${layerName} not found`,
        });
      }
      await sendToFakeSync('delete_layer', layerName, null);
      io.emit('layerUpdated', { layerName, updatedAt: new Date().toISOString() });
      res.json({ status: 'success', message: 'Layer deleted successfully' });
    } else {
      const filePath = path.join(DATA_DIR, `${layerName}.geojson`);
      try {
        await fs.unlink(filePath);
      } catch (error) {
        if (error.code === 'ENOENT') {
          return res.status(404).json({
            status: 'error',
            error: `Layer ${layerName}.geojson not found`,
          });
        }
        throw error;
      }
      await sendToFakeSync('delete_layer', layerName, null);
      io.emit('layerUpdated', { layerName, updatedAt: new Date().toISOString() });
      res.json({ status: 'success', message: 'Layer deleted successfully' });
    }
  } catch (error) {
    res.status(500).json({
      status: 'error',
      error: 'Failed to delete layer',
      details: error.message,
    });
  }
});

app.post('/api/add-layer', authMiddleware, async (req, res) => {
  try {
    const { layerName, features, storage } = req.body;
    if (!layerName || !features || !['db', 'local'].includes(storage)) {
      return res.status(400).json({
        status: 'error',
        error: 'layerName, features, and storage are required',
      });
    }

    if (req.user.role !== 'admin' && !req.user.layers.includes(layerName)) {
      return res.status(403).json({
        status: 'error',
        error: 'Access denied to this layer',
      });
    }

    if (storage === 'db') {
      let layer = await Layer.findOne({ name: layerName, storage: 'db' });
      if (layer) {
        return res.status(400).json({
          status: 'error',
          error: `Layer ${layerName} already exists`,
        });
      }
      layer = new Layer({
        name: layerName,
        data: { type: 'FeatureCollection', features },
        storage: 'db',
      });
      await layer.save();
      const responseLayer = makeLayerResponse(layer, 'db');
      await sendToFakeSync('add_layer', layerName, features);
      io.emit('layerUpdated', { layerName, updatedAt: new Date().toISOString() });
      res.json({ status: 'success', message: 'Layer added successfully', layer: responseLayer });
    } else {
      const filePath = path.join(DATA_DIR, `${layerName}.geojson`);
      try {
        await fs.access(filePath);
        return res.status(400).json({
          status: 'error',
          error: `Layer ${layerName} already exists`,
        });
      } catch (error) {
        if (error.code !== 'ENOENT') throw error;
      }
      const geojson = { type: 'FeatureCollection', features };
      await fs.writeFile(filePath, JSON.stringify(geojson, null, 2));
      const stat = await fs.stat(filePath);
      const responseLayer = { name: layerName, data: geojson, version: stat.mtimeMs, updatedAt: stat.mtime.toISOString() };
      await sendToFakeSync('add_layer', layerName, features);
      io.emit('layerUpdated', { layerName, updatedAt: new Date().toISOString() });
      res.json({ status: 'success', message: 'Layer added successfully', layer: responseLayer });
    }
  } catch (error) {
    res.status(500).json({
      status: 'error',
      error: 'Failed to add layer',
      details: error.message,
    });
  }
});

app.post('/api/update-layers', authMiddleware, async (req, res) => {
  try {
    const { layers, force, storage } = req.body;
    if (!Array.isArray(layers) || !['db', 'local'].includes(storage)) {
      return res.status(400).json({
        status: 'error',
        error: "layers must be an array and storage must be 'db' or 'local'",
      });
    }

    const accessibleLayers =
      req.user.role === 'admin'
        ? layers
        : layers.filter((layer) => req.user.layers.includes(layer.name));

    if (accessibleLayers.length === 0) {
      return res.status(403).json({
        status: 'error',
        error: 'Access denied to all provided layers',
      });
    }

    const updatedLayers = [];
    const conflicts = [];

    for (const layer of accessibleLayers) {
      if (!layer.name || !layer.data) continue;

      if (storage === 'db') {
        let dbLayer = await Layer.findOne({ name: layer.name, storage: 'db' });
        if (
          layer.version &&
          dbLayer &&
          dbLayer.updatedAt.getTime() > Number(layer.version) &&
          !force &&
          !layer.force
        ) {
          conflicts.push({
            name: layer.name,
            data: dbLayer.data,
            version: dbLayer.updatedAt.getTime(),
            updatedAt: dbLayer.updatedAt.toISOString(),
          });
          continue;
        }

        if (!dbLayer) {
          dbLayer = new Layer({
            name: layer.name,
            data: layer.data,
            storage: 'db',
          });
        } else {
          dbLayer.data = layer.data;
          dbLayer.updatedAt = new Date();
        }
        await dbLayer.save();
        await sendToFakeSync('update_layer', layer.name, layer.data);
        io.emit('layerUpdated', { layerName: layer.name, updatedAt: new Date().toISOString() });
        updatedLayers.push(layer.name);
      } else {
        const filePath = path.join(DATA_DIR, `${layer.name}.geojson`);
        try {
          const stat = await fs.stat(filePath);
          if (
            layer.version &&
            stat.mtimeMs > Number(layer.version) &&
            !force &&
            !layer.force
          ) {
            const currentContent = await fs.readFile(filePath, 'utf8');
            conflicts.push({
              name: layer.name,
              data: JSON.parse(currentContent),
              version: stat.mtimeMs,
              updatedAt: stat.mtime.toISOString(),
            });
            continue;
          }
        } catch (err) {
          if (err.code !== 'ENOENT') throw err;
        }

        try {
          await fs.stat(filePath);
          const backupPath = `${filePath}.bak.${Date.now()}`;
          await fs.copyFile(filePath, backupPath);
        } catch (err) {
          if (err.code !== 'ENOENT') throw err;
        }

        await fs.writeFile(filePath, JSON.stringify(layer.data, null, 2));
        await sendToFakeSync('update_layer', layer.name, layer.data);
        io.emit('layerUpdated', { layerName: layer.name, updatedAt: new Date().toISOString() });
        updatedLayers.push(layer.name);
      }
    }

    if (conflicts.length > 0) {
      return res.status(409).json({
        status: 'error',
        error: 'Conflict: some layers have been modified on server',
        conflicts,
        updated: updatedLayers,
      });
    }

    res.json({
      status: 'success',
      message: 'Layers updated successfully',
      updated: updatedLayers,
    });
  } catch (error) {
    res.status(500).json({
      status: 'error',
      error: 'Failed to update layers',
      details: error.message,
    });
  }
});

// replace add-parcel-property: forward to external add-feature and refresh cache
// extended to support mahalle if mahalle_id or target:'mahalle' provided
app.post('/api/add-parcel-property', authMiddleware, async (req, res) => {
  try {
    const { parcel_id, mahalle_id, key, value, target } = req.body;
    // accept either parcel_id (parcels) or mahalle_id / target==='mahalle' (mahalles)
    if ((!parcel_id && !mahalle_id) || !key || value === undefined) {
      return res.status(400).json({
        status: 'error',
        error: 'parcel_id/mahalle_id and key and value are required',
      });
    }

    const isMahalle = !!mahalle_id || target === 'mahalle';

    if (isMahalle) {
      if (
        req.user.role !== 'admin' &&
        req.user.role !== 'editor' &&
        !req.user.layers.includes('main-mahalles')
      ) {
        return res.status(403).json({
          status: 'error',
          error: 'Access denied to main-mahalles layer',
        });
      }
    } else {
      if (
        req.user.role !== 'admin' &&
        req.user.role !== 'editor' &&
        !req.user.layers.includes('main-parcels')
      ) {
        return res.status(403).json({
          status: 'error',
          error: 'Access denied to main-parcels layer',
        });
      }
    }

    const payload = isMahalle ? { mahalle_id: String(mahalle_id || parcel_id), key, value } : { parcel_id: String(parcel_id), key, value };

    // try with trailing slash first, fallback without slash
    let externalResponse;
    try {
      const endpoint = isMahalle ? `${MAHALLE_PREFIX}/add-feature/` : '/api/add-feature/';
      externalResponse = await externalAxios.post(endpoint, payload, { validateStatus: null });
    } catch (err) {
      console.warn('externalAxios POST failed:', err.message);
      try {
        const endpoint = isMahalle ? `${MAHALLE_PREFIX}/add-feature` : '/api/add-feature';
        externalResponse = await externalAxios.post(endpoint, payload, { validateStatus: null });
      } catch (err2) {
        console.error('externalAxios POST fallback failed:', err2.message);
        return res.status(502).json({
          status: 'error',
          error: 'Failed to contact upstream add-feature API',
          details: err2.message,
        });
      }
    }

    console.log(`External add-feature response: status=${externalResponse.status}`);

    if (externalResponse.status !== 200 || externalResponse.data?.status !== 'success') {
      console.error('Upstream add-feature error:', {
        status: externalResponse.status,
        data: externalResponse.data,
      });

      const statusToReturn = externalResponse.status && externalResponse.status >= 400 ? externalResponse.status : 502;
      return res.status(statusToReturn).json({
        status: 'error',
        error: 'Failed to add property to external API',
        upstream: {
          status: externalResponse.status,
          data: externalResponse.data,
        },
      });
    }

    // success -> refresh cache best-effort
    let updatedLayerData = null;
    try {
      if (isMahalle) {
        const refreshResp = await externalAxios.get('/api/mahalles', { validateStatus: null });
        if (refreshResp?.data) {
          let geojsonData = { type: 'FeatureCollection', features: [] };
          if (refreshResp.data.results && Array.isArray(refreshResp.data.results)) {
            geojsonData.features = refreshResp.data.results.map((item) => ({
              type: 'Feature',
              id: item.id,
              geometry: item.geometry,
              properties: item.properties,
            }));
          } else if (refreshResp.data.type === 'FeatureCollection') {
            geojsonData = refreshResp.data;
          }
          updatedLayerData = geojsonData;
          mahallesCache.data = updatedLayerData;
          mahallesCache.updatedAt = Date.now();
          writeMahallesToFile(updatedLayerData).catch(() => {});
        }
      } else {
        const refreshResp = await externalAxios.get('/api/parcels-geojson/', { validateStatus: null });
        if (refreshResp?.data) {
          updatedLayerData = refreshResp.data;
          parcelsCache.data = updatedLayerData;
          parcelsCache.updatedAt = Date.now();
          writeParcelsToFile(updatedLayerData).catch(() => {});
        }
      }
    } catch (refreshErr) {
      console.warn('Failed to refresh after add-parcel-property:', refreshErr.message);
    }

    await sendToFakeSync('add_property', isMahalle ? 'main-mahalles' : 'main-parcels', payload);
    io.emit('layerUpdated', { layerName: isMahalle ? 'main-mahalles' : 'main-parcels', updatedAt: new Date().toISOString() });

    return res.json({
      status: 'success',
      message: 'Property added successfully',
      feature: externalResponse.data.feature || null,
      layer: {
        name: isMahalle ? 'main-mahalles' : 'main-parcels',
        data: updatedLayerData,
        updatedAt: new Date().toISOString(),
      },
    });
  } catch (error) {
    console.error('Add parcel property error (internal):', error.stack || error.message, error.response?.data || {});
    res.status(500).json({
      status: 'error',
      error: 'Failed to add property',
      details: error.response?.data || error.message,
    });
  }
});

app.post('/api/update-parcel-property', authMiddleware, async (req, res) => {
  try {
    const { parcel_id, mahalle_id, key, value, target } = req.body;
    if ((!parcel_id && !mahalle_id) || !key || value === undefined) {
      return res.status(400).json({
        status: 'error',
        error: 'parcel_id/mahalle_id, key, and value are required',
      });
    }

    const isMahalle = !!mahalle_id || target === 'mahalle';

    if (isMahalle) {
      if (
        req.user.role !== 'admin' &&
        req.user.role !== 'editor' &&
        !req.user.layers.includes('main-mahalles')
      ) {
        return res.status(403).json({
          status: 'error',
          error: 'Access denied to main-mahalles layer',
        });
      }
    } else {
      if (
        req.user.role !== 'admin' &&
        req.user.role !== 'editor' &&
        !req.user.layers.includes('main-parcels')
      ) {
        return res.status(403).json({
          status: 'error',
          error: 'Access denied to main-parcels layer',
        });
      }
    }

    const payload = isMahalle
      ? { mahalle_id: String(mahalle_id || parcel_id), key, value }
      : { parcel_id: String(parcel_id), key, value };

    const endpoint = isMahalle ? `${MAHALLE_PREFIX}/update-feature/` : '/api/update-feature/';
    const externalResponse = await externalAxios.post(endpoint, payload, { validateStatus: null });

    if (externalResponse.data?.status !== 'success') {
      return res.status(400).json({
        status: 'error',
        error: 'Failed to update property',
        details: externalResponse.data,
      });
    }

    let updatedLayerData = null;
    try {
      if (isMahalle) {
        const refreshResponse = await externalAxios.get('/api/mahalles');
        if (refreshResponse?.data) {
          let geojsonData = { type: 'FeatureCollection', features: [] };
          if (refreshResponse.data.results && Array.isArray(refreshResponse.data.results)) {
            geojsonData.features = refreshResponse.data.results.map((item) => ({
              type: 'Feature',
              id: item.id,
              geometry: item.geometry,
              properties: item.properties,
            }));
          } else if (refreshResponse.data.type === 'FeatureCollection') {
            geojsonData = refreshResponse.data;
          }
          updatedLayerData = geojsonData;
          mahallesCache.data = updatedLayerData;
          mahallesCache.updatedAt = Date.now();
          writeMahallesToFile(updatedLayerData).catch(() => {});
        }
      } else {
        const refreshResponse = await externalAxios.get('/api/parcels-geojson/');
        if (refreshResponse?.data) {
          updatedLayerData = refreshResponse.data;
          parcelsCache.data = updatedLayerData;
          parcelsCache.updatedAt = Date.now();
          writeParcelsToFile(updatedLayerData).catch(() => {});
        }
      }
    } catch (refreshErr) {
      console.error('Failed to refresh main layer:', refreshErr.message);
    }

    await sendToFakeSync('update_property', isMahalle ? 'main-mahalles' : 'main-parcels', payload);
    io.emit('layerUpdated', { layerName: isMahalle ? 'main-mahalles' : 'main-parcels', updatedAt: new Date().toISOString() });

    res.json({
      status: 'success',
      message: 'Property updated successfully',
      feature: externalResponse.data.feature || null,
      layer: {
        name: isMahalle ? 'main-mahalles' : 'main-parcels',
        data: updatedLayerData,
        updatedAt: new Date().toISOString(),
      },
    });
  } catch (error) {
    console.error('Update parcel property error:', error.stack || error.message);
    res.status(500).json({
      status: 'error',
      error: 'Failed to update property',
      details: error.message,
    });
  }
});

app.post('/api/delete-parcel-property', authMiddleware, async (req, res) => {
  try {
    const { parcel_id, mahalle_id, key, target } = req.body;
    if ((!parcel_id && !mahalle_id) || !key) {
      return res.status(400).json({
        status: 'error',
        error: 'parcel_id/mahalle_id and key are required',
      });
    }

    const isMahalle = !!mahalle_id || target === 'mahalle';

    if (isMahalle) {
      if (
        req.user.role !== 'admin' &&
        req.user.role !== 'editor' &&
        !req.user.layers.includes('main-mahalles')
      ) {
        return res.status(403).json({
          status: 'error',
          error: 'Access denied to main-mahalles layer',
        });
      }
    } else {
      if (
        req.user.role !== 'admin' &&
        req.user.role !== 'editor' &&
        !req.user.layers.includes('main-parcels')
      ) {
        return res.status(403).json({
          status: 'error',
          error: 'Access denied to main-parcels layer',
        });
      }
    }

    const payload = isMahalle ? { mahalle_id: String(mahalle_id || parcel_id), key } : { parcel_id: String(parcel_id), key };

    // Try with trailing slash first, then fallback without it
    let externalResponse;
    try {
      const endpoint = isMahalle ? `${MAHALLE_PREFIX}/delete-feature/` : '/api/delete-feature/';
      externalResponse = await externalAxios.post(endpoint, payload, { validateStatus: null });
    } catch (err) {
      console.warn('externalAxios POST failed:', err.message);
      try {
        const endpoint = isMahalle ? `${MAHALLE_PREFIX}/delete-feature` : '/api/delete-feature';
        externalResponse = await externalAxios.post(endpoint, payload, { validateStatus: null });
      } catch (err2) {
        console.error('externalAxios POST fallback to delete-feature failed:', err2.message);
        return res.status(502).json({
          status: 'error',
          error: 'Failed to contact upstream delete-feature API',
          details: err2.message,
        });
      }
    }

    console.log(`External delete-feature response: status=${externalResponse.status}`);

    if (externalResponse.status !== 200 || externalResponse.data?.status !== 'success') {
      console.error('Upstream delete-feature error:', {
        status: externalResponse.status,
        data: externalResponse.data,
      });

      const statusToReturn = externalResponse.status && externalResponse.status >= 400 ? externalResponse.status : 502;
      return res.status(statusToReturn).json({
        status: 'error',
        error: 'Failed to delete property via external API',
        upstream: {
          status: externalResponse.status,
          data: externalResponse.data,
        },
      });
    }

    // refresh appropriate cache best-effort
    let updatedLayerData = null;
    try {
      if (isMahalle) {
        const refreshResp = await externalAxios.get('/api/mahalles', { validateStatus: null });
        if (refreshResp?.data) {
          let geojsonData = { type: 'FeatureCollection', features: [] };
          if (refreshResp.data.results && Array.isArray(refreshResp.data.results)) {
            geojsonData.features = refreshResp.data.results.map((item) => ({
              type: 'Feature',
              id: item.id,
              geometry: item.geometry,
              properties: item.properties,
            }));
          } else if (refreshResp.data.type === 'FeatureCollection') {
            geojsonData = refreshResp.data;
          }
          updatedLayerData = geojsonData;
          mahallesCache.data = updatedLayerData;
          mahallesCache.updatedAt = Date.now();
          writeMahallesToFile(updatedLayerData).catch(() => {});
        }
      } else {
        const refreshResp = await externalAxios.get('/api/parcels-geojson/', { validateStatus: null });
        if (refreshResp?.data) {
          updatedLayerData = refreshResp.data;
          parcelsCache.data = updatedLayerData;
          parcelsCache.updatedAt = Date.now();
          writeParcelsToFile(updatedLayerData).catch(() => {});
        }
      }
    } catch (refreshErr) {
      console.warn('Failed to refresh after delete-parcel-property:', refreshErr.message);
    }

    await sendToFakeSync('delete_property', isMahalle ? 'main-mahalles' : 'main-parcels', payload);
    io.emit('layerUpdated', { layerName: isMahalle ? 'main-mahalles' : 'main-parcels', updatedAt: new Date().toISOString() });

    return res.json({
      status: 'success',
      message: 'Property deleted successfully',
      feature: externalResponse.data.feature || null,
      layer: {
        name: isMahalle ? 'main-mahalles' : 'main-parcels',
        data: updatedLayerData,
        updatedAt: new Date().toISOString(),
      },
    });
  } catch (error) {
    console.error('Delete parcel property error (internal):', error.stack || error.message, error.response?.data || {});
    res.status(500).json({
      status: 'error',
      error: 'Failed to delete property',
      details: error.response?.data || error.message,
    });
  }
});

app.post('/api/upload', authMiddleware, upload.single('file'), async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({
        status: 'error',
        error: "No file uploaded (field name must be 'file')",
      });
    }

    const { option = 'add_new', storage = 'local', name, targetLayer } = req.body;
    if (!['add_new', 'replace', 'delete_and_replace'].includes(option) || !['db', 'local'].includes(storage)) {
      return res.status(400).json({
        status: 'error',
        error: 'Invalid option or storage',
      });
    }

    if ((option === 'replace' || option === 'delete_and_replace') && !targetLayer) {
      return res.status(400).json({
        status: 'error',
        error: 'targetLayer is required for replace or delete_and_replace',
      });
    }

    let layerName = name ? sanitizeLayerName(name) : `layer_${Date.now()}`;

    if (option === 'replace' || option === 'delete_and_replace') {
      layerName = targetLayer;
    }

    if (req.user.role !== 'admin' && !req.user.layers.includes(layerName)) {
      return res.status(403).json({
        status: 'error',
        error: 'Access denied to this layer',
        layer: layerName,
      });
    }

    const text = req.file.buffer.toString('utf8');
    let incomingGeo;
    try {
      incomingGeo = JSON.parse(text);
    } catch (e) {
      return res.status(400).json({
        status: 'error',
        error: 'Invalid JSON/GeoJSON',
        details: e.message,
      });
    }

    let incomingFeatures =
      incomingGeo.type === 'FeatureCollection'
        ? Array.isArray(incomingGeo.features)
          ? incomingGeo.features
          : []
        : incomingGeo.type === 'Feature'
        ? [incomingGeo]
        : [];

    if (!incomingFeatures.length) {
      return res.status(400).json({
        status: 'error',
        error: 'Please upload a Feature or FeatureCollection GeoJSON',
      });
    }

    // FIX: avoid spreading undefined properties
    incomingFeatures = incomingFeatures.map((f, idx) => ({
      ...f,
      properties: {
        ...(f.properties || {}),
        OBJECTID: f.properties?.OBJECTID ?? f.id ?? `auto_${Date.now()}_${idx}`,
      },
      id: String(f.properties?.OBJECTID ?? f.id ?? `auto_${Date.now()}_${idx}`),
    }));

    if (storage === 'db') {
      let layer = await Layer.findOne({ name: layerName, storage: 'db' });
      if (option === 'add_new' && layer) {
        return res.status(400).json({
          status: 'error',
          error: `Layer ${layerName} already exists`,
        });
      }

      if (option === 'add_new') {
        layer = new Layer({
          name: layerName,
          data: { type: 'FeatureCollection', features: incomingFeatures },
          storage: 'db',
        });
        await layer.save();
        await sendToFakeSync('add_layer', layerName, incomingFeatures);
        io.emit('layerUpdated', { layerName, updatedAt: new Date().toISOString() });
        return res.status(201).json({
          status: 'success',
          message: 'Layer uploaded successfully',
          layerName,
        });
      }

      if (!layer && (option === 'replace' || option === 'delete_and_replace')) {
        return res.status(404).json({
          status: 'error',
          error: `Layer ${layerName} not found`,
        });
      }

      if (option === 'replace') {
        const existingById = new Map(
          layer.data.features.map((f) => [String(f.properties?.OBJECTID ?? f.id), f])
        );
        let added = 0;
        let updated = 0;
        for (const f of incomingFeatures) {
          const id = String(f.properties?.OBJECTID ?? f.id);
          if (!existingById.has(id)) {
            layer.data.features.push(f);
            added++;
          } else {
            const index = layer.data.features.findIndex(
              (feat) => String(feat.properties?.OBJECTID ?? feat.id) === id
            );
            layer.data.features[index] = f;
            updated++;
          }
        }
        layer.updatedAt = new Date();
        await layer.save();
        await sendToFakeSync('replace_layer', layerName, { added, updated });
        io.emit('layerUpdated', { layerName, updatedAt: new Date().toISOString() });
        return res.status(200).json({
          status: 'success',
          message: `Layer replaced successfully, ${added} added, ${updated} updated`,
          layerName,
        });
      }

      if (option === 'delete_and_replace') {
        layer.data = { type: 'FeatureCollection', features: incomingFeatures };
        layer.updatedAt = new Date();
        await layer.save();
        await sendToFakeSync('delete_and_replace_layer', layerName, incomingFeatures);
        io.emit('layerUpdated', { layerName, updatedAt: new Date().toISOString() });
        return res.status(200).json({
          status: 'success',
          message: 'Layer deleted and replaced successfully',
          layerName,
        });
      }
    } else {
      const filePath = path.join(DATA_DIR, `${layerName}.geojson`);
      let existingGeo = { type: 'FeatureCollection', features: [] };
      try {
        const content = await fs.readFile(filePath, 'utf8');
        existingGeo = JSON.parse(content);
        if (!Array.isArray(existingGeo.features)) existingGeo.features = [];
      } catch (err) {
        if (err.code !== 'ENOENT') throw err;
      }

      if (option === 'add_new' && existingGeo.features.length > 0) {
        return res.status(400).json({
          status: 'error',
          error: `Layer ${layerName} already exists`,
        });
      }

      if (option === 'add_new') {
        await fs.writeFile(
          filePath,
          JSON.stringify({ type: 'FeatureCollection', features: incomingFeatures }, null, 2)
        );
        await sendToFakeSync('add_layer', layerName, incomingFeatures);
        io.emit('layerUpdated', { layerName, updatedAt: new Date().toISOString() });
        return res.status(201).json({
          status: 'success',
          message: 'Layer uploaded successfully',
          layerName,
        });
      }

      if (option === 'replace') {
        const existingById = new Map(
          existingGeo.features.map((f) => [String(f.properties?.OBJECTID ?? f.id), f])
        );
        let added = 0;
        let updated = 0;
        for (const f of incomingFeatures) {
          const id = String(f.properties?.OBJECTID ?? f.id);
          if (!existingById.has(id)) {
            existingGeo.features.push(f);
            added++;
          } else {
            const index = existingGeo.features.findIndex(
              (feat) => String(feat.properties?.OBJECTID ?? feat.id) === id
            );
            existingGeo.features[index] = f;
            updated++;
          }
        }
        await fs.writeFile(filePath, JSON.stringify(existingGeo, null, 2));
        await sendToFakeSync('replace_layer', layerName, { added, updated });
        io.emit('layerUpdated', { layerName, updatedAt: new Date().toISOString() });
        return res.status(200).json({
          status: 'success',
          message: `Layer replaced successfully, ${added} added, ${updated} updated`,
          layerName,
        });
      }

      if (option === 'delete_and_replace') {
        await fs.writeFile(
          filePath,
          JSON.stringify({ type: 'FeatureCollection', features: incomingFeatures }, null, 2)
        );
        await sendToFakeSync('delete_and_replace_layer', layerName, incomingFeatures);
        io.emit('layerUpdated', { layerName, updatedAt: new Date().toISOString() });
        return res.status(200).json({
          status: 'success',
          message: 'Layer deleted and replaced successfully',
          layerName,
        });
      }
    }
  } catch (error) {
    console.error('Upload handler error:', error.stack || error.message);
    res.status(500).json({
      status: 'error',
      error: 'Server error',
      details: error.message,
    });
  }
});

app.post('/api/upload-geojson', authMiddleware, upload.single('file'), async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({
        status: 'error',
        error: "No file uploaded (field name must be 'file')",
      });
    }

    const { option = 'add', storage = 'local', name, targetLayer } = req.body;
    if (!['add', 'merge', 'replace'].includes(option) || !['db', 'local'].includes(storage)) {
      return res.status(400).json({
        status: 'error',
        error: 'Invalid option or storage',
      });
    }

    if ((option === 'merge' || option === 'replace') && !targetLayer) {
      return res.status(400).json({
        status: 'error',
        error: 'targetLayer is required for merge or replace',
      });
    }

    let layerName = name ? sanitizeLayerName(name) : `layer_${Date.now()}`;

    if (option === 'merge' || option === 'replace') {
      layerName = targetLayer;
    }

    if (req.user.role !== 'admin' && !req.user.layers.includes(layerName)) {
      return res.status(403).json({
        status: 'error',
        error: 'Access denied to this layer',
        layer: layerName,
      });
    }

    const text = req.file.buffer.toString('utf8');
    let incomingGeo;
    try {
      incomingGeo = JSON.parse(text);
    } catch (e) {
      return res.status(400).json({
        status: 'error',
        error: 'Invalid JSON/GeoJSON',
        details: e.message,
      });
    }

    let incomingFeatures =
      incomingGeo.type === 'FeatureCollection'
        ? Array.isArray(incomingGeo.features)
          ? incomingGeo.features
          : []
        : incomingGeo.type === 'Feature'
        ? [incomingGeo]
        : [];

    if (!incomingFeatures.length) {
      return res.status(400).json({
        status: 'error',
        error: 'Please upload a Feature or FeatureCollection GeoJSON',
      });
    }

    // FIX: avoid spreading undefined properties
    incomingFeatures = incomingFeatures.map((f, idx) => ({
      ...f,
      properties: {
        ...(f.properties || {}),
        OBJECTID: f.properties?.OBJECTID ?? f.id ?? `auto_${Date.now()}_${idx}`,
      },
      id: String(f.properties?.OBJECTID ?? f.id ?? `auto_${Date.now()}_${idx}`),
    }));

    if (storage === 'db') {
      let layer = await Layer.findOne({ name: layerName, storage: 'db' });
      if (option === 'add' && layer) {
        return res.status(400).json({
          status: 'error',
          error: `Layer ${layerName} already exists`,
        });
      }

      if (option === 'add') {
        layer = new Layer({
          name: layerName,
          data: { type: 'FeatureCollection', features: incomingFeatures },
          storage: 'db',
        });
        await layer.save();
        await sendToFakeSync('add_layer', layerName, incomingFeatures);
        io.emit('layerUpdated', { layerName, updatedAt: new Date().toISOString() });
        return res.status(201).json({
          status: 'success',
          message: 'Layer uploaded successfully',
          layerName,
        });
      }

      if (!layer && (option === 'merge' || option === 'replace')) {
        return res.status(404).json({
          status: 'error',
          error: `Layer ${layerName} not found`,
        });
      }

      if (option === 'replace') {
        layer.data = { type: 'FeatureCollection', features: incomingFeatures };
        layer.updatedAt = new Date();
        await layer.save();
        await sendToFakeSync('replace_layer', layerName, incomingFeatures);
        io.emit('layerUpdated', { layerName, updatedAt: new Date().toISOString() });
        return res.status(200).json({
          status: 'success',
          message: 'Layer replaced successfully',
          layerName,
        });
      }

      if (option === 'merge') {
        const existingById = new Map(
          layer.data.features.map((f) => [String(f.properties?.OBJECTID ?? f.id), f])
        );
        let added = 0;
        for (const f of incomingFeatures) {
          const id = String(f.properties?.OBJECTID ?? f.id);
          if (!existingById.has(id)) {
            layer.data.features.push(f);
            existingById.set(id, f);
            added++;
          }
        }
        layer.updatedAt = new Date();
        await layer.save();
        await sendToFakeSync('merge_layer', layerName, { added });
        io.emit('layerUpdated', { layerName, updatedAt: new Date().toISOString() });
        return res.status(200).json({
          status: 'success',
          message: `Layer merged successfully, ${added} features added`,
          layerName,
        });
      }
    } else {
      const filePath = path.join(DATA_DIR, `${layerName}.geojson`);
      let existingGeo = { type: 'FeatureCollection', features: [] };
      try {
        const content = await fs.readFile(filePath, 'utf8');
        existingGeo = JSON.parse(content);
        if (!Array.isArray(existingGeo.features)) existingGeo.features = [];
      } catch (err) {
        if (err.code !== 'ENOENT') throw err;
      }

      if (option === 'add' && existingGeo.features.length > 0) {
        return res.status(400).json({
          status: 'error',
          error: `Layer ${layerName} already exists`,
        });
      }

      if (option === 'add') {
        await fs.writeFile(
          filePath,
          JSON.stringify({ type: 'FeatureCollection', features: incomingFeatures }, null, 2)
        );
        await sendToFakeSync('add_layer', layerName, incomingFeatures);
        io.emit('layerUpdated', { layerName, updatedAt: new Date().toISOString() });
        return res.status(201).json({
          status: 'success',
          message: 'Layer uploaded successfully',
          layerName,
        });
      }

      if (option === 'replace') {
        await fs.writeFile(
          filePath,
          JSON.stringify({ type: 'FeatureCollection', features: incomingFeatures }, null, 2)
        );
        await sendToFakeSync('replace_layer', layerName, incomingFeatures);
        io.emit('layerUpdated', { layerName, updatedAt: new Date().toISOString() });
        return res.status(200).json({
          status: 'success',
          message: 'Layer replaced successfully',
          layerName,
        });
      }

      if (option === 'merge') {
        const existingById = new Map(
          existingGeo.features.map((f) => [String(f.properties?.OBJECTID ?? f.id), f])
        );
        let added = 0;
        for (const f of incomingFeatures) {
          const id = String(f.properties?.OBJECTID ?? f.id);
          if (!existingById.has(id)) {
            existingGeo.features.push(f);
            existingById.set(id, f);
            added++;
          }
        }
        await fs.writeFile(filePath, JSON.stringify(existingGeo, null, 2));
        await sendToFakeSync('merge_layer', layerName, { added });
        io.emit('layerUpdated', { layerName, updatedAt: new Date().toISOString() });
        return res.status(200).json({
          status: 'success',
          message: `Layer merged successfully, ${added} features added`,
          layerName,
        });
      }
    }
  } catch (error) {
    console.error('Upload-geojson handler error:', error.stack || error.message);
    res.status(500).json({
      status: 'error',
      error: 'Server error',
      details: error.message,
    });
  }
});

app.post('/api/_tmp_register_admin', async (req, res) => {
  try {
    const { username, password } = req.body;
    if (!username || !password) {
      return res.status(400).json({
        status: 'error',
        error: 'username & password required',
      });
    }

    const hashed = await bcrypt.hash(password, 10);
    const user = new User({
      username,
      password: hashed,
      role: 'admin',
      tools: [
        'stats',
        'edit',
        'export',
        'spatial',
        'visual',
        'network',
        'join',
        'modeling',
        'draw',
        'filter',
        'search',
      ],
      layers: ['test'],
    });

    await user.save();
    res.status(201).json({
      status: 'success',
      message: 'Admin registered successfully',
      username: user.username,
    });
  } catch (error) {
    res.status(500).json({
      status: 'error',
      error: error.message,
    });
  }
});

app.post('/api/admin/refresh-cache', authMiddleware, adminMiddleware, async (req, res) => {
  try {
    const { layers } = req.body; // e.g. ['main-parcels', 'main-mahalles']
    const results = {};
    if (!Array.isArray(layers) || layers.length === 0) {
      return res.status(400).json({ status:'error', error: 'layers array required' });
    }

    for (const layer of layers) {
      if (layer === 'main-parcels') {
        parcelsCache.updatedAt = 0;
        try { const r = await fetchParcelsFromExternal(); results[layer] = { ok: true, fromCache: r.fromCache }; }
        catch(e){ results[layer] = { ok:false, error: e.message }; }
      } else if (layer === 'main-mahalles') {
        mahallesCache.updatedAt = 0;
        try { const r = await fetchMahallesFromExternal(); results[layer] = { ok: true, fromCache: r.fromCache }; }
        catch(e){ results[layer] = { ok:false, error: e.message }; }
      } else if (layer === 'main-mabar') {
        mabarCache.updatedAt = 0;
        try { const r = await fetchMabarFromExternal(); results[layer] = { ok: true, fromCache: r.fromCache }; }
        catch(e){ results[layer] = { ok:false, error: e.message }; }
      } else {
        results[layer] = { ok:false, error: 'unknown layer' };
      }
    }

    return res.json({ status:'success', results });

  } catch (err) {
    return res.status(500).json({ status:'error', error: err.message });
  }
});

const hashForETag = (obj) => {
  const str = typeof obj === 'string' ? obj : JSON.stringify(obj);
  return crypto.createHash('sha1').update(str).digest('hex');
};

// --- Diagnostic catch-all 404 (place at end of file, before server.listen) ---
app.use((req, res, next) => {
  const now = new Date().toISOString();
  const ip = req.headers['x-forwarded-for'] || req.socket.remoteAddress || req.ip;
  console.warn(`[NOT-FOUND] ${now} ${ip} ${req.method} ${req.originalUrl}`);
  res.status(404).json({
    status: 'error',
    error: 'Not found (diagnostic)',
    method: req.method,
    url: req.originalUrl,
    note: 'If you still see a different 404 page (HTML) in the browser, the request likely does not reach this Node process (proxy/service-worker/nginx).'
  });
});



const PORT = process.env.PORT || 5000;
server.listen(PORT, () => console.log(`Server running on port ${PORT}`));