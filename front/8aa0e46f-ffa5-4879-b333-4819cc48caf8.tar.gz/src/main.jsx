import React from 'react';
import ReactDOM from 'react-dom/client';
import { BrowserRouter } from 'react-router-dom';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import App from './App.jsx';
import './index.css';

// ایجاد یک نمونه از QueryClient
const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      retry: 2, // تعداد تلاش‌های مجدد برای درخواست‌های ناموفق
      staleTime: 5 * 60 * 1000, // زمان کش داده‌ها (۵ دقیقه)
      onError: (error) => {
        console.error('Query error:', error);
      },
    },
    mutations: {
      onError: (error) => {
        console.error('Mutation error:', error);
      },
    },
  },
});

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <QueryClientProvider client={queryClient}>
      <BrowserRouter>
        <App />
      </BrowserRouter>
    </QueryClientProvider>
  </React.StrictMode>
);