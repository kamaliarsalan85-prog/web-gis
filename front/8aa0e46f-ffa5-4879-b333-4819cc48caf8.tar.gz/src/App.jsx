// App.jsx
import React, { useEffect } from 'react';
import { Routes, Route } from 'react-router-dom';
import Login from './AuthComponents/Login';
import AdminDashboard from './AuthComponents/AdminDashboard';
import CoreMap from '../src/components/CoreMap';
import ErrorBoundary from './ErrorBoundary';
import { ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import axios from 'axios';

const App = () => {
  // اینترسپتور برای اضافه کردن توکن به تمام درخواست‌ها
  useEffect(() => {
    const requestInterceptor = axios.interceptors.request.use(
      (config) => {
        const token = localStorage.getItem('token');
        if (token) {
          config.headers.Authorization = `Bearer ${token}`;
        }
        return config;
      },
      (error) => {
        return Promise.reject(error);
      }
    );

    // پاک کردن اینترسپتور وقتی کامپوننت آنماونت می‌شود
    return () => {
      axios.interceptors.request.eject(requestInterceptor);
    };
  }, []);

  return (
    <ErrorBoundary>
      <Routes>
        <Route path="/login" element={<Login />} />
        <Route path="/admin" element={<AdminDashboard />} />
        <Route path="/map" element={<CoreMap />} />
        <Route path="/" element={<Login />} />
      </Routes>
      <ToastContainer />
    </ErrorBoundary>
  );
};

export default App;