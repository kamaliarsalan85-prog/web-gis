// src/services/api.js
import axios from 'axios';
import { toast } from 'react-toastify';

const api = axios.create({
  baseURL: 'https://mazdagis-api.liara.run',
  timeout: 30000,
});

// request interceptor: ثبت timestamp شروع (در metadata فقط) + اضافه کردن Authorization اگر موجود باشد
api.interceptors.request.use((config) => {
  const start = Date.now();
  config.metadata = { start }; // فقط metadata — هیچ هدر سفارشی اضافه نکن (غیر از Authorization که خودکار اضافه می‌کنیم)
  try {
    const token = localStorage.getItem('token');
    if (token) {
      config.headers = config.headers || {};
      config.headers.Authorization = `Bearer ${token}`;
    }
  } catch (e) {
    // ignore localStorage access errors
  }
  return config;
});

// response interceptor: محاسبه duration و لاگ خلاصه + هندل 401
api.interceptors.response.use(
  (response) => {
    const start = response.config?.metadata?.start ? Number(response.config.metadata.start) : Date.now();
    const duration = Date.now() - start;
    try {
      const serverFetch = response.headers['x-fetch-time-ms'] || null;
      const xcache = response.headers['x-cache'] || null;
      const contentLength =
        response.headers['content-length'] ||
        (response.data ? (typeof response.data === 'string' ? response.data.length : JSON.stringify(response.data).length) : null);
      console.info(
        '[API] %s %s -> %s  client-ms=%d server-ms=%s x-cache=%s size=%s',
        (response.config.method || '').toUpperCase(),
        response.config.url,
        response.status,
        duration,
        serverFetch,
        xcache,
        contentLength
      );
    } catch (e) {
      console.log('[API] response logging error', e);
    }
    return response;
  },
  (error) => {
    const cfg = error.config || {};
    const start = cfg?.metadata?.start || Date.now();
    const duration = Date.now() - start;
    console.error(
      '[API][ERR] %s %s -> (%d ms) error: %s',
      (cfg.method || '').toUpperCase(),
      cfg.url || '',
      duration,
      error.message
    );
    if (error.response) {
      console.error('  status:', error.response.status, 'headers:', error.response.headers);
      // مرکزی هندل کردن 401:
      if (error.response.status === 401) {
        try {
          toast.error('نشانه‌گذاری نامعتبر یا منقضی شده — لطفاً دوباره وارد شوید');
        } catch (e) {}
        try {
          localStorage.removeItem('token');
        } catch (e) {}
        // redirect به /login بعد از کمی تاخیر تا toast دیده بشه
        setTimeout(() => {
          // اگر شما SPA route متفاوتی دارید، می‌تونید این خط رو به router push تغییر بدید
          window.location.href = '/login';
        }, 300);
      }
    }
    return Promise.reject(error);
  }
);

export default api;
